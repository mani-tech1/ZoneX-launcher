package com.example.tapzones

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class PickerState(var h: Float, var s: Float, var v: Float) {
    fun color(): Int = Color.HSVToColor(floatArrayOf(h, s, v))
    fun set(c: Int) {
        val a = FloatArray(3)
        Color.colorToHSV(c, a)
        h = a[0]; s = a[1]; v = a[2]
    }
}

private fun textOn(c: Int): Int =
    if (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c) > 150) Color.BLACK else Color.WHITE

private fun hexOf(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

/** Colour box: drag left/right for the colour, up/down for how vivid it is. */
class HueSatView(ctx: Context, private val st: PickerState, private val onChange: () -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val hues = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = 16 * d
        rect.set(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, 0f, hues, null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = LinearGradient(0f, 0f, 0f, h, 0x00FFFFFF, 0xFFFFFFFF.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        p.color = Color.argb(((1f - st.v) * 255).toInt(), 0, 0, 0)
        c.drawRoundRect(rect, r, r, p)
        val cx = st.h / 360f * w; val cy = (1f - st.s) * h
        p.color = st.color(); c.drawCircle(cx, cy, 10 * d, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3 * d; p.color = Color.WHITE; c.drawCircle(cx, cy, 11.5f * d, p)
        p.strokeWidth = 1.2f * d; p.color = 0x66000000; c.drawCircle(cx, cy, 13.5f * d, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            parent.requestDisallowInterceptTouchEvent(true)
            st.h = (e.x / width * 360f).coerceIn(0f, 360f)
            st.s = (1f - e.y / height).coerceIn(0f, 1f)
            onChange(); invalidate()
        }
        return true
    }
}

/** Darkness slider on the right: light at the top, dark at the bottom. */
class ValueSliderView(ctx: Context, private val st: PickerState, private val onChange: () -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = 14 * d
        rect.set(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h, Color.HSVToColor(floatArrayOf(st.h, st.s, 1f)), Color.BLACK, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        val cy = ((1f - st.v) * h).coerceIn(10 * d, h - 10 * d)
        rect.set(1.5f * d, cy - 9 * d, w - 1.5f * d, cy + 9 * d)
        p.color = Color.WHITE; c.drawRoundRect(rect, 9 * d, 9 * d, p)
        rect.inset(3 * d, 3 * d)
        p.color = st.color(); c.drawRoundRect(rect, 6 * d, 6 * d, p)
        rect.set(1.5f * d, cy - 9 * d, w - 1.5f * d, cy + 9 * d)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = 0x66000000
        c.drawRoundRect(rect, 9 * d, 9 * d, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            parent.requestDisallowInterceptTouchEvent(true)
            st.v = (1f - e.y / height).coerceIn(0f, 1f)
            onChange(); invalidate()
        }
        return true
    }
}

/** Old colour on the left, new colour (with its hex code) on the right. */
class PreviewView(ctx: Context, private val st: PickerState, private val old: Int) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val path = Path()
        path.addRoundRect(RectF(0f, 0f, w, h), 16 * d, 16 * d, Path.Direction.CW)
        c.save(); c.clipPath(path)
        p.color = old; c.drawRect(0f, 0f, w / 2, h, p)
        val cur = st.color()
        p.color = cur; c.drawRect(w / 2, 0f, w, h, p)
        c.restore()
        tp.color = textOn(old); tp.textSize = 12 * d
        c.drawText("OLD", w / 4, h / 2 + 4 * d, tp)
        tp.color = textOn(cur); tp.textSize = 11 * d
        c.drawText("NEW", w * 0.75f, h * 0.36f, tp)
        tp.textSize = 17 * d
        c.drawText(hexOf(cur), w * 0.75f, h * 0.70f, tp)
    }
}

/**
 * The one colour picker used everywhere in ZoneX: colour box (drag), darkness slider,
 * hex code, quick colours, shades and recently used colours.
 */
class ColorPicker(private val a: Activity, private val cfg: Cfg) {
    private val d = a.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val quick = listOf(0xFFEF5350, 0xFFFFA726, 0xFFFFEE58, 0xFF66BB6A, 0xFF29B6F6, 0xFF5C6BC0, 0xFFAB47BC).map { it.toInt() }
    private val shades = listOf(0xFFFFFFFF, 0xFFCFD8DC, 0xFF90A4AE, 0xFF546E7A, 0xFF263238, 0xFF000000, 0xFFEC407A).map { it.toInt() }

    private fun recent(): List<Int> = cfg.s("recent_colors", "").split(",").mapNotNull { it.toIntOrNull() }
    private fun pushRecent(c: Int) {
        val l = (listOf(c) + recent().filter { it != c }).take(7)
        cfg.setS("recent_colors", l.joinToString(","))
    }

    private fun close(x: Int, y: Int) =
        Math.abs(Color.red(x) - Color.red(y)) + Math.abs(Color.green(x) - Color.green(y)) + Math.abs(Color.blue(x) - Color.blue(y)) <= 6

    fun show(initial: Int, title: String = "Pick a color", onPick: (Int) -> Unit) {
        val th = Th(cfg.b("dark", true))
        val accent = cfg.color("accent", 1)
        val old = initial or 0xFF000000.toInt()
        val st = PickerState(0f, 0f, 1f)
        st.set(old)

        lateinit var pv: PreviewView
        lateinit var hs: HueSatView
        lateinit var vs: ValueSliderView
        lateinit var hex: EditText
        val swatches = ArrayList<Pair<View, Int>>()
        var updatingHex = false

        fun styleSwatches() {
            val cur = st.color()
            for ((v, col) in swatches) {
                val on = close(col, cur)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(if (on) dp(3) else dp(1), if (on) th.text else th.sub)
                }
            }
        }

        fun sync(fromHex: Boolean) {
            pv.invalidate(); hs.invalidate(); vs.invalidate()
            if (!fromHex) {
                updatingHex = true
                hex.setText(hexOf(st.color()))
                updatingHex = false
            }
            styleSwatches()
        }

        fun label(t: String) = TextView(a).apply {
            text = t; textSize = 12f; setTextColor(th.sub)
            setPadding(dp(2), dp(14), 0, dp(6))
        }

        fun swatchRow(colors: List<Int>): LinearLayout {
            val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
            colors.forEachIndexed { i, col ->
                val v = View(a)
                v.setOnClickListener { st.set(col); sync(false) }
                swatches.add(v to col)
                row.addView(v, LinearLayout.LayoutParams(dp(38), dp(38)))
                if (i < colors.size - 1) row.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
            }
            return row
        }

        val dlg = Dialog(a)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            background = GradientDrawable().apply { cornerRadius = 26 * d; setColor(th.base) }
        }
        root.addView(TextView(a).apply {
            text = title; textSize = 18f; setTextColor(th.text)
            setTypeface(typeface, Typeface.BOLD)
        })

        pv = PreviewView(a, st, old)
        root.addView(pv, LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(12) })

        hs = HueSatView(a, st) { sync(false) }
        vs = ValueSliderView(a, st) { sync(false) }
        val pickRow = LinearLayout(a)
        pickRow.addView(hs, LinearLayout.LayoutParams(0, -1, 1f))
        pickRow.addView(vs, LinearLayout.LayoutParams(dp(40), -1).apply { leftMargin = dp(14) })
        root.addView(pickRow, LinearLayout.LayoutParams(-1, dp(210)).apply { topMargin = dp(14) })
        root.addView(TextView(a).apply {
            text = "Drag in the box to pick a color  •  slider on the right = darkness"
            textSize = 11f; setTextColor(th.sub); setPadding(dp(2), dp(8), 0, 0)
        })

        val hexRow = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        hexRow.addView(TextView(a).apply {
            text = "HEX"; textSize = 12f; setTextColor(th.sub); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), 0, dp(12), 0)
        })
        hex = EditText(a).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(7))
            setTextColor(th.text)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = 14 * d; setColor(th.card) }
        }
        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (updatingHex) return
                val t = s.toString().trim().removePrefix("#")
                if (t.length == 6 && t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                    st.set(Color.parseColor("#$t")); sync(true)
                }
            }
        })
        hexRow.addView(hex, LinearLayout.LayoutParams(0, -2, 1f))
        hexRow.addView(TextView(a).apply {
            text = "Reset"; textSize = 13f; setTextColor(accent); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(10), dp(6), dp(10))
            setOnClickListener { st.set(old); sync(false) }
        })
        root.addView(hexRow)

        root.addView(label("Quick colors"))
        root.addView(swatchRow(quick))
        root.addView(label("Shades"))
        root.addView(swatchRow(shades))
        val rec = recent()
        if (rec.isNotEmpty()) {
            root.addView(label("Recent"))
            root.addView(swatchRow(rec))
        }

        val btns = LinearLayout(a).apply { gravity = Gravity.END; setPadding(0, dp(18), 0, 0) }
        btns.addView(TextView(a).apply {
            text = "Cancel"; textSize = 14f; setTextColor(th.sub); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(22), dp(12), dp(22), dp(12))
            setOnClickListener { dlg.dismiss() }
        })
        btns.addView(TextView(a).apply {
            text = "Apply"; textSize = 14f; setTextColor(textOn(accent)); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(28), dp(12), dp(28), dp(12))
            background = GradientDrawable().apply { cornerRadius = 18 * d; setColor(accent) }
            setOnClickListener {
                val col = st.color()
                pushRecent(col)
                dlg.dismiss()
                onPick(col)
            }
        })
        root.addView(btns)

        val sv = ScrollView(a)
        sv.addView(root)
        dlg.setContentView(sv)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(0))
            setLayout((a.resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        sync(false)
        dlg.show()
    }
}
