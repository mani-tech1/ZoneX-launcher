package com.example.tapzones

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

abstract class PanelBase(val m: MainActivity) : FrameLayout(m) {
    protected val cfg: Cfg get() = m.cfg
    protected val d = resources.displayMetrics.density
    protected fun dp(v: Int) = (v * d).toInt()
    protected var th = Th(true)
    protected var accent = 0

    protected abstract fun refresh()
    protected open fun live() {}

    protected fun themeUp() {
        th = Th(cfg.b("dark", true)); accent = cfg.color("accent", 1)
        setBackgroundColor(th.base)
    }

    protected fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(m).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }

    protected fun sec(c: LinearLayout, t: String) {
        c.addView(tv(t, 13f, accent, true).apply { setPadding(dp(6), dp(18), 0, dp(6)) })
    }

    protected fun note(c: LinearLayout, t: String) {
        c.addView(tv(t, 12.5f, th.sub).apply { setPadding(dp(6), dp(4), dp(6), dp(8)) })
    }

    protected fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val g = GradientDrawable()
        g.cornerRadius = 12 * d
        g.setColor(if (selected) th.sel else th.base)
        if (selected) g.setStroke((1.5f * d).toInt(), accent)
        return tv(text, 12.5f, if (selected) accent else th.sub, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = g
            setOnClickListener { onClick() }
        }
    }

    protected fun item(c: LinearLayout, title: String, sub: String, onClick: () -> Unit) {
        val row = LinearLayout(m).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            flat(th, 14)
            setOnClickListener { onClick() }
        }
        row.addView(tv(title, 15f, th.text, true))
        if (sub.isNotEmpty()) row.addView(tv(sub, 12f, th.sub))
        c.addView(row, lp())
    }

    protected fun button(c: LinearLayout, text: String, onClick: () -> Unit) {
        val b = tv(text, 14f, accent, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(14), dp(18), dp(14))
            flat(th, 14)
            setOnClickListener { onClick() }
        }
        c.addView(b, lp())
    }

    protected fun toggle(c: LinearLayout, label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val on = get()
        val row = LinearLayout(m).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(12), dp(10))
            flat(th, 14)
        }
        row.addView(tv(label, 14.5f, th.text), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(chip(if (on) "ON" else "OFF", on) { set(!on); live(); refresh() })
        c.addView(row, lp())
    }

    protected fun slider(c: LinearLayout, label: String, get: () -> Int, set: (Int) -> Unit,
                         min: Int, max: Int, unit: String) {
        val box = LinearLayout(m).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(8))
            flat(th, 14)
        }
        val lab = tv(label + ": " + get() + unit, 14f, th.text)
        val sb = SeekBar(m)
        sb.max = max - min
        sb.progress = (get() - min).coerceIn(0, max - min)
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val v = p + min
                set(v); lab.text = label + ": " + v + unit; live()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lab)
        box.addView(sb, LinearLayout.LayoutParams(-1, -2))
        c.addView(box, lp())
    }

    protected fun colorRow(c: LinearLayout, label: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(m).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            flat(th, 14)
            setOnClickListener { colorDialog(get()) { set(it); live(); refresh() } }
        }
        row.addView(tv(label, 14.5f, th.text), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = View(m)
        sw.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(PALETTE[get().coerceIn(0, PALETTE.size - 1)])
            setStroke(dp(2), th.sub)
        }
        row.addView(sw, LinearLayout.LayoutParams(dp(30), dp(30)))
        c.addView(row, lp())
    }

    protected fun colorDialog(cur: Int, done: (Int) -> Unit) {
        val box = LinearLayout(m).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        lateinit var dlg: AlertDialog
        PALETTE.indices.chunked(5).forEach { grp ->
            val row = LinearLayout(m)
            grp.forEach { i ->
                val sw = View(m)
                sw.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(PALETTE[i])
                    setStroke(dp(if (i == cur) 3 else 1), if (i == cur) Color.WHITE else Color.GRAY)
                }
                sw.setOnClickListener { done(i); dlg.dismiss() }
                row.addView(sw, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) })
            }
            box.addView(row)
        }
        dlg = AlertDialog.Builder(m).setTitle("Pick a color").setView(box).setNegativeButton("Cancel", null).create()
        dlg.show()
    }

    protected fun pickList(title: String, names: List<String>, cur: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(m).setTitle(title)
            .setSingleChoiceItems(names.toTypedArray(), cur) { dlg, i -> onPick(i); dlg.dismiss() }
            .show()
    }
}
