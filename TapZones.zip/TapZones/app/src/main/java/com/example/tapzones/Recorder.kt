package com.example.tapzones

import android.app.Activity
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class RecorderPanel(private val a: Activity, private val cfg: Cfg,
                    private val onRecorded: (List<FloatArray>) -> Unit) : FrameLayout(a) {
    var onCancel: (() -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val temps = ArrayList<FloatArray>()
    private val pts = ArrayList<PointF>()
    private val path = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val title = TextView(a).apply { textSize = 20f; gravity = Gravity.CENTER }
    private val sub = TextView(a).apply { textSize = 14f; gravity = Gravity.CENTER; text = "Draw with your finger, for example the letter C" }
    private val cancel = TextView(a).apply {
        text = "Cancel"; textSize = 15f; gravity = Gravity.CENTER
        setPadding((28 * d).toInt(), (14 * d).toInt(), (28 * d).toInt(), (14 * d).toInt())
        setOnClickListener { onCancel?.invoke() }
    }
    private val canvasView = object : View(a) {
        override fun onDraw(c: Canvas) {
            paint.color = cfg.color("g_color", 1)
            c.drawPath(path, paint)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { pts.clear(); path.reset(); path.moveTo(e.x, e.y); pts.add(PointF(e.x, e.y)) }
                MotionEvent.ACTION_MOVE -> { path.lineTo(e.x, e.y); pts.add(PointF(e.x, e.y)); invalidate() }
                MotionEvent.ACTION_UP -> {
                    val n = if (pts.size >= 8) Rec.norm(pts) else null
                    if (n == null) {
                        Toast.makeText(a, "Too short, try again", Toast.LENGTH_SHORT).show()
                    } else {
                        temps.add(n)
                        if (temps.size >= 2) {
                            val t = ArrayList(temps); temps.clear()
                            onRecorded(t)
                        } else title.text = "Draw the same shape once more (2/2)"
                    }
                    path.reset(); invalidate()
                }
            }
            return true
        }
    }

    init {
        isClickable = true
        visibility = View.GONE
        addView(canvasView, LayoutParams(-1, -1))
        addView(title, LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = (90 * d).toInt() })
        addView(sub, LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = (130 * d).toInt() })
        addView(cancel, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (50 * d).toInt() })
    }

    fun start() {
        val th = Th(cfg.b("dark", true))
        setBackgroundColor(th.base)
        title.setTextColor(th.text); sub.setTextColor(th.sub); cancel.setTextColor(th.text)
        cancel.flat(th, 16)
        temps.clear(); path.reset()
        title.text = "Draw your shape (1/2)"
        visibility = View.VISIBLE
        canvasView.invalidate()
    }
}
