package com.example.tapzones

import android.content.Context
import android.graphics.*
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object ClockStyles {
    val NAMES = listOf("Bare typography", "Ring dial", "Line dial", "Analog hands", "Word clock", "Digital + date",
        "Analog with ticks", "Frosted glass", "Split-flap", "LED matrix", "Neumorphic card", "Skeuomorphic analog")
    val FONTS = listOf("Light", "Regular", "Bold", "Serif", "Mono")
    val TICKS = listOf("None", "Hours", "All marks", "Dots")

    fun isAnalog(s: Int) = s == 3 || s == 6 || s == 11

    // default size in dp (width, height)
    fun size(w: Widget): Pair<Float, Float> = when {
        w.type != 0 -> 130f to 130f
        w.style == 1 || isAnalog(w.style) -> 200f to 200f
        w.style == 2 -> 260f to 110f
        w.style == 4 -> 260f to 150f
        w.style == 8 || w.style == 9 -> 280f to 120f
        else -> 270f to 110f
    }

    fun resize(w: Widget, d: Float) {
        val cx = (w.l + w.r) / 2; val cy = (w.t + w.b) / 2
        val (wd, hd) = size(w)
        w.l = cx - wd * d / 2; w.r = cx + wd * d / 2; w.t = cy - hd * d / 2; w.b = cy + hd * d / 2
    }

    fun defaults(w: Widget) {
        w.c1 = 0; w.c2 = 1; w.cb = 9; w.alpha = 55; w.shadow = true; w.font = 1; w.thick = 4; w.ticks = 1
        when (w.style) {
            0 -> w.font = 0
            6 -> w.alpha = 35
            7 -> { w.cb = 0; w.alpha = 40 }
            8 -> { w.cb = 9; w.alpha = 85; w.font = 2; w.shadow = false }
            9 -> { w.c1 = 1; w.c2 = 4; w.shadow = false }
            10 -> { w.cb = 0; w.alpha = 100; w.c1 = 9; w.c2 = 1; w.shadow = false }
            11 -> { w.c1 = 9; w.c2 = 5; w.ticks = 2; w.shadow = false; w.thick = 3 }
        }
        if (w.type != 0) { w.cb = 9; w.alpha = 45 }
    }
}

object ClockDraw {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val HW = arrayOf("twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven")
    private val GLYPH = arrayOf("111101101101111", "010110010010111", "111001111100111", "111001111001111",
        "101101111001001", "111100111001111", "111100111101111", "111001001001001", "111101111101111", "111101111001111")

    private fun col(i: Int, a: Int = 255): Int {
        val c = PALETTE[i.coerceIn(0, PALETTE.size - 1)]
        return Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
    }
    private fun al(w: Widget) = (w.alpha * 255 / 100).coerceIn(0, 255)

    private fun face(w: Widget): Typeface = when (w.font) {
        0 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif", Typeface.BOLD)
        3 -> Typeface.SERIF
        4 -> Typeface.MONOSPACE
        else -> Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun hh(w: Widget, cal: Calendar): String {
        val h = cal.get(Calendar.HOUR_OF_DAY)
        return if (w.h24) "%02d".format(h) else (if (h % 12 == 0) 12 else h % 12).toString()
    }

    private fun tstr(w: Widget, cal: Calendar, withAmPm: Boolean): String {
        var s = hh(w, cal) + ":" + "%02d".format(cal.get(Calendar.MINUTE))
        if (w.sec) s += ":" + "%02d".format(cal.get(Calendar.SECOND))
        if (withAmPm && w.ampm && !w.h24) s += if (cal.get(Calendar.HOUR_OF_DAY) < 12) " AM" else " PM"
        return s
    }

    private fun dline(w: Widget, cal: Calendar, batt: Int): String {
        var s = if (w.date) SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(cal.time) else ""
        if (w.batt && batt >= 0) s += (if (s.isEmpty()) "" else "  •  ") + batt + "%"
        return s
    }

    private fun fit(c: Canvas, s: String, cx: Float, cy: Float, mw: Float, mh: Float, color: Int, w: Widget) {
        if (s.isEmpty() || mw <= 0f || mh <= 0f) return
        tp.style = Paint.Style.FILL
        tp.typeface = face(w); tp.color = color; tp.textAlign = Paint.Align.CENTER; tp.textSize = mh
        val wd = tp.measureText(s)
        if (wd > mw) tp.textSize = mh * mw / wd
        if (w.shadow) tp.setShadowLayer(6f, 0f, 2f, 0x99000000.toInt()) else tp.clearShadowLayer()
        val fm = tp.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    fun draw(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        p.shader = null; p.clearShadowLayer(); p.style = Paint.Style.FILL
        val cx = r.centerX(); val cy = r.centerY(); val ww = r.width(); val hh = r.height()
        when (w.type) {
            1 -> battery(c, w, r, batt, d)
            2 -> dateCard(c, w, r, cal, d)
            else -> when (w.style) {
                0 -> fit(c, tstr(w, cal, true), cx, cy, ww, hh * 0.9f, col(w.c1), w)
                1 -> ring(c, w, r, cal, batt, d)
                2 -> lineDial(c, w, r, cal, batt, d)
                3 -> analog(c, w, cx, cy, min(ww, hh) / 2f * 0.95f, cal, false, d)
                4 -> word(c, w, r, cal)
                5 -> digital(c, w, r, cal, batt, d)
                6 -> {
                    val rad = min(ww, hh) / 2f * 0.95f
                    p.style = Paint.Style.FILL; p.color = col(w.cb, al(w)); c.drawCircle(cx, cy, rad, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = col(w.c1, 120); c.drawCircle(cx, cy, rad, p)
                    analog(c, w, cx, cy, rad, cal, false, d)
                }
                7 -> glass(c, w, r, cal, batt, d)
                8 -> flap(c, w, r, cal, d)
                9 -> led(c, w, r, cal)
                10 -> neu(c, w, r, cal, batt, d)
                else -> skeu(c, w, cx, cy, min(ww, hh) / 2f * 0.95f, cal, d)
            }
        }
    }

    private fun digital(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        val cx = r.centerX(); val cy = r.centerY(); val ww = r.width(); val hh = r.height()
        val dl = dline(w, cal, batt)
        if (dl.isEmpty()) { fit(c, tstr(w, cal, true), cx, cy, ww, hh * 0.8f, col(w.c1), w); return }
        fit(c, tstr(w, cal, true), cx, cy - hh * 0.14f, ww, hh * 0.58f, col(w.c1), w)
        p.style = Paint.Style.FILL; p.color = col(w.c2)
        val bw = ww * 0.18f
        c.drawRoundRect(cx - bw / 2, cy + hh * 0.2f, cx + bw / 2, cy + hh * 0.2f + 2.5f * d, 2f * d, 2f * d, p)
        fit(c, dl, cx, cy + hh * 0.36f, ww, hh * 0.2f, col(w.c2), w)
    }

    private fun ring(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        val cx = r.centerX(); val cy = r.centerY()
        val rad = min(r.width(), r.height()) / 2f - w.thick * d
        p.style = Paint.Style.STROKE; p.strokeWidth = w.thick * d; p.strokeCap = Paint.Cap.ROUND
        p.color = col(w.c1, 50); c.drawCircle(cx, cy, rad, p)
        p.color = col(w.c2)
        val frac = if (w.sec) cal.get(Calendar.SECOND) / 60f else cal.get(Calendar.MINUTE) / 60f
        rf.set(cx - rad, cy - rad, cx + rad, cy + rad)
        c.drawArc(rf, -90f, 360f * frac, false, p)
        p.style = Paint.Style.FILL
        val dl = dline(w, cal, batt)
        val iw = rad * 1.5f
        if (dl.isEmpty()) fit(c, tstr(w, cal, false), cx, cy, iw, rad * 0.7f, col(w.c1), w)
        else {
            fit(c, tstr(w, cal, false), cx, cy - rad * 0.1f, iw, rad * 0.55f, col(w.c1), w)
            fit(c, dl, cx, cy + rad * 0.42f, iw, rad * 0.2f, col(w.c2), w)
        }
    }

    private fun lineDial(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        val cx = r.centerX(); val cy = r.centerY(); val ww = r.width(); val hh = r.height()
        fit(c, tstr(w, cal, true), cx, cy - hh * 0.12f, ww, hh * 0.5f, col(w.c1), w)
        val y = cy + hh * 0.28f
        val x0 = r.left + ww * 0.08f; val x1 = r.right - ww * 0.08f
        p.style = Paint.Style.STROKE; p.strokeWidth = w.thick * d; p.strokeCap = Paint.Cap.ROUND
        p.color = col(w.c1, 60); c.drawLine(x0, y, x1, y, p)
        val frac = (cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f) / 60f
        val xe = x0 + (x1 - x0) * frac
        p.color = col(w.c2); c.drawLine(x0, y, xe, y, p)
        p.style = Paint.Style.FILL; c.drawCircle(xe, y, w.thick * d * 1.4f, p)
        val dl = dline(w, cal, batt)
        fit(c, dl, cx, cy + hh * 0.43f, ww, hh * 0.14f, col(w.c2), w)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, ang: Float, len: Float, wd: Float, color: Int, shade: Boolean, d: Float) {
        val a = Math.toRadians(ang - 90.0)
        val ex = cx + len * cos(a).toFloat(); val ey = cy + len * sin(a).toFloat()
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = wd
        if (shade) { p.color = 0x55000000; c.drawLine(cx + 2 * d, cy + 3 * d, ex + 2 * d, ey + 3 * d, p) }
        p.color = color; c.drawLine(cx, cy, ex, ey, p)
    }

    private fun analog(c: Canvas, w: Widget, cx: Float, cy: Float, rad: Float, cal: Calendar, shade: Boolean, d: Float) {
        if (w.ticks > 0) {
            val n = if (w.ticks == 2) 60 else 12
            for (i in 0 until n) {
                val big = w.ticks != 2 || i % 5 == 0
                val a = Math.toRadians(i * 360.0 / n - 90.0)
                val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
                if (w.ticks == 3) {
                    p.style = Paint.Style.FILL; p.color = col(w.c1)
                    c.drawCircle(cx + ca * rad * 0.9f, cy + sa * rad * 0.9f, 2.5f * d, p)
                } else {
                    val r1 = rad * (if (big) 0.84f else 0.91f)
                    p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
                    p.strokeWidth = (if (big) 2.4f else 1.2f) * d
                    p.color = col(w.c1, if (big) 255 else 150)
                    c.drawLine(cx + ca * r1, cy + sa * r1, cx + ca * rad * 0.98f, cy + sa * rad * 0.98f, p)
                }
            }
        }
        val h = cal.get(Calendar.HOUR_OF_DAY) % 12; val m = cal.get(Calendar.MINUTE); val s = cal.get(Calendar.SECOND)
        hand(c, cx, cy, (h + m / 60f) * 30f, rad * 0.5f, w.thick * 1.6f * d, col(w.c1), shade, d)
        hand(c, cx, cy, (m + s / 60f) * 6f, rad * 0.75f, w.thick * 1.1f * d, col(w.c1), shade, d)
        if (w.sec) hand(c, cx, cy, s * 6f, rad * 0.85f, w.thick * 0.5f * d, col(w.c2), shade, d)
        p.style = Paint.Style.FILL; p.color = col(if (w.sec) w.c2 else w.c1)
        c.drawCircle(cx, cy, w.thick * 1.3f * d, p)
    }

    private fun word(c: Canvas, w: Widget, r: RectF, cal: Calendar) {
        val h = cal.get(Calendar.HOUR_OF_DAY); val m = cal.get(Calendar.MINUTE)
        var hr = h % 12; var mm = (m + 2) / 5 * 5
        if (mm >= 60) { mm = 0; hr = (hr + 1) % 12 }
        if (mm > 30) hr = (hr + 1) % 12
        val ph = when (mm) {
            0 -> ""; 5 -> "five past"; 10 -> "ten past"; 15 -> "quarter past"; 20 -> "twenty past"
            25 -> "twenty-five past"; 30 -> "half past"; 35 -> "twenty-five to"; 40 -> "twenty to"
            45 -> "quarter to"; 50 -> "ten to"; else -> "five to"
        }
        val hw = HW[hr] + (if (mm == 0) " o'clock" else "")
        val lines = listOf("it's", ph, hw).filter { it.isNotEmpty() }
        val lh = r.height() / lines.size
        lines.forEachIndexed { i, s ->
            fit(c, s, r.centerX(), r.top + lh * (i + 0.5f), r.width(), lh * 0.8f,
                col(if (i == lines.size - 1) w.c1 else w.c2), w)
        }
    }

    private fun glass(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        val rr = min(r.height() * 0.25f, 30f * d)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(r.left, r.top, r.right, r.bottom, col(w.cb, al(w)), col(w.cb, al(w) / 3), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rr, rr, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = col(w.cb, 120)
        c.drawRoundRect(r, rr, rr, p)
        p.style = Paint.Style.FILL
        digital(c, w, r, cal, batt, d)
    }

    private fun flap(c: Canvas, w: Widget, r: RectF, cal: Calendar, d: Float) {
        val s = tstr(w, cal, false)
        val digits = s.count { it != ':' }; val colons = s.count { it == ':' }; val n = s.length
        var cw = r.width() / (digits + 0.4f * colons + 0.06f * (n - 1))
        cw = min(cw, r.height() * 0.9f / 1.45f)
        val ch = cw * 1.45f; val gap = cw * 0.06f
        val total = digits * cw + colons * 0.4f * cw + gap * (n - 1)
        var x = r.centerX() - total / 2; val top = r.centerY() - ch / 2
        for (chr in s) {
            if (chr == ':') {
                p.style = Paint.Style.FILL; p.color = col(w.c2)
                val xm = x + 0.2f * cw
                c.drawCircle(xm, r.centerY() - ch * 0.15f, cw * 0.06f, p)
                c.drawCircle(xm, r.centerY() + ch * 0.15f, cw * 0.06f, p)
                x += 0.4f * cw + gap
            } else {
                p.style = Paint.Style.FILL; p.color = col(w.cb, al(w))
                c.drawRoundRect(x, top, x + cw, top + ch, cw * 0.14f, cw * 0.14f, p)
                fit(c, chr.toString(), x + cw / 2, r.centerY(), cw * 0.8f, ch * 0.62f, col(w.c1), w)
                p.style = Paint.Style.FILL; p.color = 0xAA000000.toInt()
                c.drawRect(x, r.centerY() - 0.8f * d, x + cw, r.centerY() + 0.8f * d, p)
                x += cw + gap
            }
        }
    }

    private fun dot(c: Canvas, x: Float, y: Float, rad: Float, on: Boolean, ci: Int, offCi: Int) {
        p.style = Paint.Style.FILL
        p.color = if (on) col(ci) else col(offCi, 35)
        c.drawCircle(x, y, rad, p)
    }

    private fun led(c: Canvas, w: Widget, r: RectF, cal: Calendar) {
        val s = tstr(w, cal, false)
        var cols = 0
        for (ch in s) cols += if (ch == ':') 2 else 4
        cols -= 1
        val pitch = min(r.width() / cols, r.height() / 5f / 1.15f)
        val rad = pitch * 0.38f
        val x0 = r.centerX() - cols * pitch / 2; val y0 = r.centerY() - 2.5f * pitch
        var cc = 0
        for (ch in s) {
            if (ch == ':') {
                for (rr in 0 until 5) dot(c, x0 + (cc + 0.5f) * pitch, y0 + (rr + 0.5f) * pitch, rad, rr == 1 || rr == 3, w.c2, w.c1)
                cc += 2
            } else {
                val g = GLYPH[ch - '0']
                for (rr in 0 until 5) for (k in 0 until 3)
                    dot(c, x0 + (cc + k + 0.5f) * pitch, y0 + (rr + 0.5f) * pitch, rad, g[rr * 3 + k] == '1', w.c1, w.c1)
                cc += 4
            }
        }
    }

    private fun neu(c: Canvas, w: Widget, r: RectF, cal: Calendar, batt: Int, d: Float) {
        val rr = min(r.height() * 0.22f, 28f * d); val m = 8f * d
        val card = RectF(r.left + m, r.top + m, r.right - m, r.bottom - m)
        p.style = Paint.Style.FILL
        for (i in 4 downTo 1) {
            val o = i * 1.6f * d
            p.color = Color.argb(24, 0, 0, 0); rf.set(card); rf.offset(o, o); c.drawRoundRect(rf, rr, rr, p)
            p.color = Color.argb(30, 255, 255, 255); rf.set(card); rf.offset(-o, -o); c.drawRoundRect(rf, rr, rr, p)
        }
        p.color = col(w.cb); c.drawRoundRect(card, rr, rr, p)
        digital(c, w, card, cal, batt, d)
    }

    private fun skeu(c: Canvas, w: Widget, cx: Float, cy: Float, rad: Float, cal: Calendar, d: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad,
            intArrayOf(0xFFF5F5F5.toInt(), 0xFF8A8A8A.toInt(), 0xFFE8E8E8.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, p)
        p.shader = RadialGradient(cx, cy, rad * 0.88f, intArrayOf(0xFFFFF8E1.toInt(), 0xFFE0D2AE.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad * 0.88f, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0x44000000
        c.drawCircle(cx, cy, rad * 0.88f, p)
        analog(c, w, cx, cy, rad * 0.88f, cal, true, d)
    }

    private fun battery(c: Canvas, w: Widget, r: RectF, batt: Int, d: Float) {
        val rr = min(r.width(), r.height()) * 0.22f
        p.style = Paint.Style.FILL; p.color = col(w.cb, al(w)); c.drawRoundRect(r, rr, rr, p)
        val cx = r.centerX(); val cy = r.centerY()
        val rad = min(r.width(), r.height()) / 2f * 0.62f
        p.style = Paint.Style.STROKE; p.strokeWidth = w.thick * d; p.strokeCap = Paint.Cap.ROUND
        p.color = col(w.c1, 50); c.drawCircle(cx, cy, rad, p)
        p.color = col(w.c2)
        rf.set(cx - rad, cy - rad, cx + rad, cy + rad)
        if (batt >= 0) c.drawArc(rf, -90f, 360f * batt / 100f, false, p)
        p.style = Paint.Style.FILL
        fit(c, if (batt >= 0) "$batt%" else "--", cx, cy, rad * 1.3f, rad * 0.7f, col(w.c1), w)
    }

    private fun dateCard(c: Canvas, w: Widget, r: RectF, cal: Calendar, d: Float) {
        val rr = min(r.width(), r.height()) * 0.22f
        p.style = Paint.Style.FILL; p.color = col(w.cb, al(w)); c.drawRoundRect(r, rr, rr, p)
        val cx = r.centerX(); val cy = r.centerY(); val ww = r.width(); val hh = r.height()
        val loc = Locale.getDefault()
        fit(c, SimpleDateFormat("EEE", loc).format(cal.time).uppercase(), cx, r.top + hh * 0.2f, ww * 0.8f, hh * 0.16f, col(w.c2), w)
        fit(c, cal.get(Calendar.DAY_OF_MONTH).toString(), cx, cy + hh * 0.02f, ww * 0.8f, hh * 0.5f, col(w.c1), w)
        fit(c, SimpleDateFormat("MMM", loc).format(cal.time).uppercase(), cx, r.bottom - hh * 0.18f, ww * 0.8f, hh * 0.15f, col(w.c2), w)
    }
}

class ClockPreview(ctx: Context, private val w: Widget, private val batt: () -> Int) : View(ctx) {
    private val bg = Paint()
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val vw = width.toFloat(); val vh = height.toFloat()
        bg.shader = LinearGradient(0f, 0f, vw, vh,
            intArrayOf(0xFF1E1B4B.toInt(), 0xFF6D28D9.toInt(), 0xFF0EA5E9.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, vw, vh, 16 * d, 16 * d, bg)
        val ww = w.r - w.l; val hh = w.b - w.t
        if (ww <= 1f || hh <= 1f) return
        val s = min((vw - 32 * d) / ww, (vh - 24 * d) / hh)
        val rw = ww * s; val rh = hh * s
        val rect = RectF(vw / 2 - rw / 2, vh / 2 - rh / 2, vw / 2 + rw / 2, vh / 2 + rh / 2)
        ClockDraw.draw(c, w, rect, Calendar.getInstance(), batt(), d * s)
        postInvalidateDelayed(1000)
    }
}
