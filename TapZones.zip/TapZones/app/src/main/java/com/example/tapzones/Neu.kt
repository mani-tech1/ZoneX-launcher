package com.example.tapzones

import android.graphics.drawable.GradientDrawable
import android.view.View

class Th(val dark: Boolean) {
    val base = if (dark) 0xFF17181C.toInt() else 0xFFF2F3F5.toInt()
    val card = if (dark) 0xFF24262C.toInt() else 0xFFFFFFFF.toInt()
    val sel = if (dark) 0xFF343741.toInt() else 0xFFE1E4EA.toInt()
    val text = if (dark) 0xFFE6E8EC.toInt() else 0xFF22252B.toInt()
    val sub = if (dark) 0xFF9AA0AD.toInt() else 0xFF6B7385.toInt()
}

fun View.flat(th: Th, rad: Int = 12, selected: Boolean = false, accent: Int = 0) {
    val d = resources.displayMetrics.density
    val g = GradientDrawable()
    g.cornerRadius = rad * d
    g.setColor(if (selected) th.sel else th.card)
    if (accent != 0) g.setStroke((1.5f * d).toInt().coerceAtLeast(1), accent)
    background = g
}
