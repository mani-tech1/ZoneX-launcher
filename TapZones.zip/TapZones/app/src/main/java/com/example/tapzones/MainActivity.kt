package com.example.tapzones

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var zv: ZoneView
    private lateinit var top: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var hint: TextView
    private lateinit var tvPage: TextView
    private lateinit var bDbl: Button
    private lateinit var bSgl: Button
    private lateinit var bDel: Button
    private lateinit var dimView: View
    private lateinit var clockLayer: FrameLayout
    private lateinit var clockBox: LinearLayout
    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView
    private lateinit var drawer: DrawerPanel
    private lateinit var settings: SettingsPanel
    private lateinit var store: GestureStore
    private lateinit var recorder: RecorderPanel

    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateClock(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun labelOf(pkg: String?): String = appLabel(this, pkg)

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val root = FrameLayout(this)

        dimView = View(this)
        root.addView(dimView, FrameLayout.LayoutParams(-1, -1))

        tvTime = TextView(this).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false; gravity = Gravity.CENTER
            setShadowLayer(8f, 0f, 2f, 0x88000000.toInt())
        }
        tvDate = TextView(this).apply {
            textSize = 16f; gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, 0x88000000.toInt())
        }
        clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        }
        clockBox.addView(tvTime)
        clockBox.addView(tvDate)
        clockLayer = FrameLayout(this)
        clockLayer.cameraDistance = 12000f * resources.displayMetrics.density
        clockLayer.addView(clockBox, FrameLayout.LayoutParams(-2, -2))
        root.addView(clockLayer, FrameLayout.LayoutParams(-1, -1))

        store = GestureStore(this)
        zv = ZoneView(this, cfg, store)
        root.addView(zv, FrameLayout.LayoutParams(-1, -1))

        top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD000000.toInt())
            setPadding(dp(8), dp(28), dp(8), dp(8))
            visibility = View.GONE
        }
        val navRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        navRow.addView(btn("‹") { zv.goTo(zv.cur() - 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        tvPage = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER }
        navRow.addView(tvPage, LinearLayout.LayoutParams(0, -2, 2f))
        navRow.addView(btn("›") { zv.goTo(zv.cur() + 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(navRow)
        val row2 = LinearLayout(this)
        row2.addView(btn("+ Add zone") { zv.addZone() }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("Reset all") {
            AlertDialog.Builder(this).setMessage("Delete ALL zones on ALL screens?")
                .setPositiveButton("Delete") { _, _ -> zv.resetAll() }
                .setNegativeButton("Cancel", null).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("Done") { zv.setEditMode(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(row2)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD000000.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(24))
            visibility = View.GONE
        }
        hint = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            text = "Tap a zone to select it. Drag to move, pull the white dots to resize. Use ‹ › for other screens."
        }
        bDbl = btn("") { choose { p -> zv.sel?.dbl = p } }
        bSgl = btn("") { choose { p -> zv.sel?.sgl = p } }
        bDel = btn("Delete this zone") { zv.deleteSelected() }
        panel.addView(hint)
        panel.addView(bDbl); panel.addView(bSgl); panel.addView(bDel)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        drawer = DrawerPanel(this, cfg,
            { pkg -> drawer.close(); packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } },
            { pkg -> drawer.close(); zv.setEditMode(true); zv.addZone(pkg) })
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))

        settings = SettingsPanel(this, cfg, store, { applyConfig() }, { zv.resetAll() }, { recorder.start() })
        settings.onClose = { settings.visibility = View.GONE }
        root.addView(settings, FrameLayout.LayoutParams(-1, -1))

        recorder = RecorderPanel(this, cfg) { temps ->
            choose(false, { recorder.start() }) { pkg ->
                if (pkg != null) {
                    store.add(pkg, temps)
                    recorder.visibility = View.GONE
                    settings.rebuild()
                }
            }
        }
        recorder.onCancel = { recorder.visibility = View.GONE }
        root.addView(recorder, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)

        zv.onChange = { refreshUi() }
        zv.onScroll = { applyClockTf(it) }
        zv.onSwipeUp = { if (cfg.b("dr_on", true)) drawer.open() }
        zv.onSwipeDown = { expandNotifications() }
        zv.onGesture = { pkg ->
            zv.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
            packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        }
        zv.onSettings = { zv.setEditMode(false); settings.rebuild(); settings.visibility = View.VISIBLE }

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
        applyConfig()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        drawer.close(); settings.visibility = View.GONE; recorder.visibility = View.GONE
        if (!zv.edit) zv.goTo(0)
    }

    private fun applyClockTf(pos: Float) {
        val p = -pos
        if (abs(p) >= 1f) { clockLayer.visibility = View.INVISIBLE; return }
        clockLayer.visibility = View.VISIBLE
        val dm = resources.displayMetrics
        val w = (if (clockLayer.width > 0) clockLayer.width else dm.widthPixels).toFloat()
        val hh = (if (clockLayer.height > 0) clockLayer.height else dm.heightPixels).toFloat()
        val t = Fx.tf(cfg.i("fx", 0), p, w, hh)
        clockLayer.pivotX = t.px; clockLayer.pivotY = t.py
        clockLayer.translationX = t.tx
        clockLayer.scaleX = t.sx; clockLayer.scaleY = t.sy
        clockLayer.rotationY = t.ry; clockLayer.rotation = t.rz
        clockLayer.alpha = t.a
    }

    private fun updateClock() {
        val now = Date()
        val is24 = cfg.b("clock24", false)
        val pat = (if (is24) "HH:mm" else "h:mm") + (if (cfg.b("sec_show", false)) ":ss" else "")
        val sb = SpannableStringBuilder(SimpleDateFormat(pat, Locale.getDefault()).format(now))
        if (!is24) {
            val st = sb.length
            sb.append(" " + SimpleDateFormat("a", Locale.getDefault()).format(now))
            sb.setSpan(RelativeSizeSpan(0.3f), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        tvTime.text = sb
        var line = if (cfg.b("date_show", true)) SimpleDateFormat("EEEE, d MMM", Locale.getDefault()).format(now) else ""
        if (cfg.b("batt_show", true)) {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            if (lv >= 0 && sc > 0) line += (if (line.isEmpty()) "" else "   •   ") + (lv * 100 / sc) + "%"
        }
        tvDate.text = line
        tvDate.visibility = if (line.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun applyConfig() {
        clockBox.visibility = if (cfg.b("clock_show", true)) View.VISIBLE else View.GONE
        tvTime.textSize = cfg.i("clock_size", 64).toFloat()
        val cc = cfg.color("clock_color", 0)
        tvTime.setTextColor(cc); tvDate.setTextColor(cc)
        val lp = when (cfg.i("clock_pos", 0)) {
            1 -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
            2 -> FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(140) }
            else -> FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(90) }
        }
        clockBox.layoutParams = lp
        updateClock()
        dimView.setBackgroundColor((cfg.i("bg_dim", 0) * 255 / 100) shl 24)
        applyBackground()
        applyClockTf(zv.scrollPos)
        zv.invalidate()
    }

    private fun refreshUi() {
        top.visibility = if (zv.edit) View.VISIBLE else View.GONE
        panel.visibility = if (zv.edit) View.VISIBLE else View.GONE
        tvPage.text = "Screen " + (zv.cur() + 1) + " / " + zv.pageCount()
        val s = zv.sel
        val has = s != null
        hint.visibility = if (has) View.GONE else View.VISIBLE
        bDbl.visibility = if (has) View.VISIBLE else View.GONE
        bSgl.visibility = if (has) View.VISIBLE else View.GONE
        bDel.visibility = if (has) View.VISIBLE else View.GONE
        if (s != null) {
            bDbl.text = "Double-tap app: " + labelOf(s.dbl)
            bSgl.text = "Single-tap app (optional): " + labelOf(s.sgl)
        }
    }

    private fun choose(allowNone: Boolean = true, onCancel: () -> Unit = {}, set: (String?) -> Unit) {
        val apps = loadApps(this)
        var shown = apps
        val et = EditText(this).apply { hint = "Search app"; isSingleLine = true }
        val lv = ListView(this)
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                }
                row.addView(ImageView(this@MainActivity).apply { setImageDrawable(shown[p].icon) },
                    LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(this@MainActivity).apply {
                    text = shown[p].label; textSize = 16f; setPadding(dp(14), 0, 0, 0)
                })
                return row
            }
        }
        lv.adapter = adapter
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        box.addView(et)
        box.addView(lv, LinearLayout.LayoutParams(-1, dp(400)))
        val bld = AlertDialog.Builder(this).setTitle("Choose app").setView(box)
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
        if (allowNone) bld.setNeutralButton("None") { _, _ -> set(null); zv.save(); zv.invalidate(); refreshUi() }
        val dlg = bld.create()
        dlg.setOnCancelListener { onCancel() }
        lv.setOnItemClickListener { _, _, p, _ ->
            set(shown[p].pkg); zv.save(); zv.invalidate(); refreshUi(); dlg.dismiss()
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = apps.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })
        dlg.show()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        applyBackground()
    }

    private fun applyBackground() {
        if (cfg.i("bg_mode", 0) == 1) {
            window.setBackgroundDrawable(ColorDrawable(cfg.color("bg_color", 9))); return
        }
        try {
            val wd: Drawable? = WallpaperManager.getInstance(this).drawable
            if (wd != null) { window.setBackgroundDrawable(wd); return }
        } catch (e: Exception) { }
        window.setBackgroundDrawable(ColorDrawable(Color.parseColor("#1B2733")))
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            sb!!.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open notifications on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        when {
            recorder.visibility == View.VISIBLE -> recorder.visibility = View.GONE
            settings.visibility == View.VISIBLE -> settings.visibility = View.GONE
            drawer.isOpen -> drawer.close()
            zv.edit -> zv.setEditMode(false)
        }
    }
}
