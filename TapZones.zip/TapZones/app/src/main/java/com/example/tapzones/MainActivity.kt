package com.example.tapzones

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.os.Build
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class MainActivity : Activity() {
    lateinit var cfg: Cfg
    lateinit var zv: ZoneView
    lateinit var look: Look
    lateinit var stats: Stats
    lateinit var editor: WidgetEditor
    lateinit var advanced: AdvancedPanel
    private lateinit var store: GestureStore
    private lateinit var top: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var hint: TextView
    private lateinit var tvPage: TextView
    private lateinit var bDbl: Button
    private lateinit var bSgl: Button
    private lateinit var bLng: Button
    private lateinit var bDel: Button
    private lateinit var bWid: Button
    private lateinit var bWdel: Button
    private lateinit var bNatDel: Button
    private lateinit var bNatCfg: Button
    lateinit var awm: AppWidgetManager
    lateinit var host: ZHost
    lateinit var nativeLayer: NativeLayer
    lateinit var picker: AppWidgetPicker
    private lateinit var bShow: Button
    private lateinit var bDone2: Button
    private var collapsed = false
    private lateinit var dimView: View
    private lateinit var drawer: DrawerPanel
    private lateinit var settings: SettingsPanel
    private lateinit var recorder: RecorderPanel
    private lateinit var surprise: SurpriseView

    private val h = Handler(Looper.getMainLooper())
    private var ticks = 0
    private var lastAuto = ""
    private val tick = object : Runnable {
        override fun run() {
            zv.batt = readBattery()
            zv.invalidate()
            if (ticks % 60 == 0) checkAuto()
            ticks++
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun launchPkg(pkg: String, src: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) { stats.hit(pkg, src); startActivity(i) } else toast("App not found")
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        look = Look(this)
        stats = Stats(this)
        store = GestureStore(this)
        if (look.isNew()) makeDefaultClock()

        val root = FrameLayout(this)
        dimView = View(this)
        root.addView(dimView, FrameLayout.LayoutParams(-1, -1))

        zv = ZoneView(this, cfg, store, look, stats)
        root.addView(zv, FrameLayout.LayoutParams(-1, -1))
        awm = AppWidgetManager.getInstance(this)
        host = ZHost(this)
        nativeLayer = NativeLayer(this)
        root.addView(nativeLayer, FrameLayout.LayoutParams(-1, -1))

        top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xB0000000.toInt())
            setPadding(dp(8), dp(28), dp(8), dp(8))
            visibility = View.GONE
        }
        val navRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        navRow.addView(btn("‹") { zv.goTo(zv.cur() - 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        tvPage = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER }
        navRow.addView(tvPage, LinearLayout.LayoutParams(0, -2, 2f))
        navRow.addView(btn("›") { zv.goTo(zv.cur() + 1) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(navRow)
        val row2 = LinearLayout(this)
        row2.addView(btn("+ Zone") { zv.addZone() }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("+ Widget") {
            AlertDialog.Builder(this).setTitle("Add widget")
                .setItems(arrayOf("Clock…", "Battery card", "Date card", "App widgets…")) { _, i ->
                    when (i) {
                        0 -> pickStyle { s -> zv.addWidget(0, s) }
                        1 -> zv.addWidget(1, 0)
                        2 -> zv.addWidget(2, 0)
                        else -> picker.open()
                    }
                }.show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("Reset") {
            AlertDialog.Builder(this).setMessage("Delete ALL zones and widgets on ALL screens?")
                .setPositiveButton("Delete") { _, _ -> zv.resetEverything() }
                .setNegativeButton("Cancel", null).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("Done") { zv.setEditMode(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(row2)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xB0000000.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(24))
            visibility = View.GONE
        }
        hint = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f
            text = "Tap a zone or widget to select it. Drag to move, pull the white dots to resize. Use ‹ › for other screens."
        }
        bDbl = btn("") { choose { p -> zv.sel?.dbl = p } }
        bSgl = btn("") { choose { p -> zv.sel?.sgl = p } }
        bLng = btn("") { choose { p -> zv.sel?.lng = p } }
        bDel = btn("Delete this zone") { zv.deleteSelected() }
        bWid = btn("Customize this widget") { zv.selW?.let { editor.open(it) } }
        bWdel = btn("Delete this widget") { zv.deleteSelected() }
        bNatDel = btn("Remove this app widget") { zv.deleteSelected() }
        bNatCfg = btn("Widget settings") { zv.selN?.let { configureNative(it) } }
        panel.addView(btn("Hide options ▾") { collapsed = true; refreshUi() })
        panel.addView(hint)
        for (b in listOf(bDbl, bSgl, bLng, bDel, bWid, bWdel, bNatCfg, bNatDel)) panel.addView(b)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        bShow = btn("▲ Options") { collapsed = false; refreshUi() }.apply { visibility = View.GONE }
        root.addView(bShow, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        bDone2 = btn("Done") { zv.setEditMode(false) }.apply { visibility = View.GONE }
        root.addView(bDone2, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(30); rightMargin = dp(8) })

        drawer = DrawerPanel(this, cfg,
            { pkg -> drawer.close(); launchPkg(pkg, "list") },
            { pkg -> drawer.close(); guard("lock_edit", false) { zv.setEditMode(true); zv.addZone(pkg) } },
            { drawer.close(); guard("lock_adv", true) { showVault() } })
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        drawer.preload()

        settings = SettingsPanel(this, cfg, store, { applyConfig() }, { zv.resetAll() },
            { recorder.start() }, { clocksDialog() })
        settings.onClose = { settings.visibility = View.GONE }
        root.addView(settings, FrameLayout.LayoutParams(-1, -1))

        advanced = AdvancedPanel(this)
        root.addView(advanced, FrameLayout.LayoutParams(-1, -1))
        editor = WidgetEditor(this)
        root.addView(editor, FrameLayout.LayoutParams(-1, -1))
        picker = AppWidgetPicker(this)
        root.addView(picker, FrameLayout.LayoutParams(-1, -1))

        recorder = RecorderPanel(this, cfg) { temps ->
            choose(false, { recorder.start() }) { pkg ->
                if (pkg != null) {
                    store.add(pkg, temps)
                    recorder.visibility = View.GONE
                    settings.rebuild()
                }
            }
        }
        recorder.onCancel = { recorder.visibility = View.GONE }
        root.addView(recorder, FrameLayout.LayoutParams(-1, -1))

        surprise = SurpriseView(this)
        root.addView(surprise, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)

        zv.onChange = { refreshUi() }
        zv.onSwipeUp = { if (cfg.b("dr_on", true)) drawer.open() }
        zv.onSwipeDown = { expandNotifications() }
        zv.onDrawerDrag = { off -> drawer.dragOpen(off) }
        zv.onDrawerEnd = { vy, cancel -> drawer.endOpenDrag(vy, cancel) }
        zv.onGesture = { pkg ->
            zv.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
            launchPkg(pkg, "shape")
        }
        zv.onEditRequest = { guard("lock_edit", false) { zv.setEditMode(true) } }
        zv.onSettings = { guard("lock_set", true) { settings.rebuild(); settings.visibility = View.VISIBLE } }
        zv.onAdvanced = { guard("lock_adv", true) { advanced.open() } }
        zv.onAdvCue = {
            val first = !cfg.b("adv_seen", false)
            cfg.set("adv_seen", true)
            surprise.play(if (first) 2200L else 1200L)
        }

        zv.onScroll = { nativeLayer.applyTf(zv.scrollPos) }
        zv.onNativeGeom = { n, fin -> nativeLayer.relayout(n); if (fin) pushSize(n) }
        zv.onNativeRemoved = { n ->
            nativeLayer.remove(n)
            try { host.deleteAppWidgetId(n.id) } catch (e: Exception) { }
        }
        nativeLayer.onLongPress = { guard("lock_edit", false) { zv.setEditMode(true) } }
        for (n in look.natives) nativeLayer.add(n, makeNativeView(n))
        nativeLayer.applyTf(zv.scrollPos)

        if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
        applyConfig()
    }

    override fun onStart() {
        super.onStart()
        try { host.startListening() } catch (e: Exception) { }
    }

    override fun onStop() {
        try { host.stopListening() } catch (e: Exception) { }
        super.onStop()
    }

    override fun onResume() { super.onResume(); h.post(tick); drawer.preload() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        drawer.close(); settings.visibility = View.GONE; recorder.visibility = View.GONE
        editor.visibility = View.GONE; advanced.close(); picker.close()
        if (!zv.edit) zv.goTo(0)
    }

    // ---------- default clock for first run / upgrade ----------
    private fun makeDefaultClock() {
        if (cfg.b("clock_show", true)) {
            val dm = resources.displayMetrics
            val w = Widget(0f, 0f, 0f, 0f, 0, 0, 5)
            ClockStyles.defaults(w)
            w.h24 = cfg.b("clock24", false); w.sec = cfg.b("sec_show", false)
            w.date = cfg.b("date_show", true); w.batt = cfg.b("batt_show", true)
            w.c1 = cfg.i("clock_color", 0)
            val (wd, hd) = ClockStyles.size(w)
            val cx = dm.widthPixels / 2f
            val top = when (cfg.i("clock_pos", 0)) {
                1 -> (dm.heightPixels - hd * dm.density) / 2f
                2 -> dm.heightPixels - 140 * dm.density - hd * dm.density
                else -> 90 * dm.density
            }
            w.l = cx - wd * dm.density / 2; w.r = cx + wd * dm.density / 2
            w.t = top; w.b = top + hd * dm.density
            look.widgets.add(w)
        }
        look.save()
    }

    private fun readBattery(): Int {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (lv >= 0 && sc > 0) lv * 100 / sc else -1
    }

    private fun applyConfig() {
        dimView.setBackgroundColor((cfg.i("bg_dim", 0) * 255 / 100) shl 24)
        applyBackground()
        nativeLayer.applyTf(zv.scrollPos)
        zv.invalidate()
    }

    private fun refreshUi() {
        if (!zv.edit) collapsed = false
        top.visibility = if (zv.edit && !collapsed) View.VISIBLE else View.GONE
        panel.visibility = if (zv.edit && !collapsed) View.VISIBLE else View.GONE
        bShow.visibility = if (zv.edit && collapsed) View.VISIBLE else View.GONE
        bDone2.visibility = if (zv.edit && collapsed) View.VISIBLE else View.GONE
        tvPage.text = "Screen " + (zv.cur() + 1) + " / " + zv.pageCount()
        val z = zv.sel
        val wd = zv.selW
        val nw = zv.selN
        hint.visibility = if (z == null && wd == null && nw == null) View.VISIBLE else View.GONE
        bNatDel.visibility = if (nw != null) View.VISIBLE else View.GONE
        bNatCfg.visibility = if (nw != null && canReconfigure(nw)) View.VISIBLE else View.GONE
        nativeLayer.editing = zv.edit; nativeLayer.selected = nw; nativeLayer.invalidate()
        for (b in listOf(bDbl, bSgl, bLng, bDel)) b.visibility = if (z != null) View.VISIBLE else View.GONE
        for (b in listOf(bWid, bWdel)) b.visibility = if (wd != null) View.VISIBLE else View.GONE
        if (z != null) {
            bDbl.text = "Double-tap app: " + appLabel(this, z.dbl)
            bSgl.text = "Single-tap app (optional): " + appLabel(this, z.sgl)
            bLng.text = "Long-press app (optional): " + appLabel(this, z.lng)
        }
    }

    // ---------- PIN ----------
    fun guard(flag: String, def: Boolean, ok: () -> Unit) {
        if (!cfg.hasPin() || !cfg.b(flag, def)) { ok(); return }
        askPin("Enter PIN", true) { pin -> if (cfg.checkPin(pin)) ok() else toast("Wrong PIN") }
    }

    fun askPin(title: String, forgot: Boolean, onPin: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "PIN"
        }
        val b = AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> onPin(et.text.toString()) }
            .setNegativeButton("Cancel", null)
        if (forgot) b.setNeutralButton("Forgot PIN?") { _, _ ->
            AlertDialog.Builder(this)
                .setMessage("The only way back in is to erase ALL app data (zones, shapes, looks, settings and the PIN). Erase everything?")
                .setPositiveButton("Erase") { _, _ -> wipeAll() }
                .setNegativeButton("Cancel", null).show()
        }
        b.show()
    }

    fun askNewPin(onDone: (String) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val type = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val e1 = EditText(this).apply { inputType = type; hint = "New PIN (4 to 6 digits)" }
        val e2 = EditText(this).apply { inputType = type; hint = "Repeat PIN" }
        box.addView(e1); box.addView(e2)
        AlertDialog.Builder(this).setTitle("Set PIN").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val a = e1.text.toString(); val b = e2.text.toString()
                if (a.length in 4..6 && a == b) onDone(a) else toast("PINs must match and be 4 to 6 digits")
            }
            .setNegativeButton("Cancel", null).show()
    }

    fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); isSingleLine = true }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- clocks ----------
    fun pickStyle(onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle("Clock style")
            .setItems(ClockStyles.NAMES.toTypedArray()) { _, i -> onPick(i) }.show()
    }

    private fun clocksDialog() {
        val ws = look.widgets
        val items = ArrayList<String>()
        ws.forEach {
            val n = if (it.type == 0) ClockStyles.NAMES[it.style.coerceIn(0, ClockStyles.NAMES.size - 1)]
                else if (it.type == 1) "Battery card" else "Date card"
            items.add("Screen " + (it.page + 1) + " · " + n)
        }
        items.add("+ Add clock to this screen")
        items.add("+ App widget…")
        AlertDialog.Builder(this).setTitle("Clock and widgets")
            .setItems(items.toTypedArray()) { _, i ->
                if (i < ws.size) editor.open(ws[i])
                else if (i == ws.size) pickStyle { s -> editor.open(zv.addWidget(0, s)) }
                else picker.open()
            }.show()
    }

    // ---------- app lists ----------
    private fun showAppList(title: String, apps: List<App>, allowNone: Boolean, onCancel: () -> Unit, onPick: (App?) -> Unit) {
        var shown = apps
        val et = EditText(this).apply { hint = "Search app"; isSingleLine = true }
        val lv = ListView(this)
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                }
                row.addView(ImageView(this@MainActivity).apply { setImageDrawable(shown[p].icon) },
                    LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(this@MainActivity).apply {
                    text = shown[p].label; textSize = 16f; setPadding(dp(14), 0, 0, 0)
                })
                return row
            }
        }
        lv.adapter = adapter
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        box.addView(et)
        box.addView(lv, LinearLayout.LayoutParams(-1, dp(400)))
        val bld = AlertDialog.Builder(this).setTitle(title).setView(box)
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
        if (allowNone) bld.setNeutralButton("None") { _, _ -> onPick(null) }
        val dlg = bld.create()
        dlg.setOnCancelListener { onCancel() }
        lv.setOnItemClickListener { _, _, p, _ -> onPick(shown[p]); dlg.dismiss() }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = apps.filter { it.label.lowercase().contains(q) }
                adapter.notifyDataSetChanged()
            }
        })
        dlg.show()
    }

    private fun choose(allowNone: Boolean = true, onCancel: () -> Unit = {}, set: (String?) -> Unit) {
        showAppList("Choose app", loadApps(this), allowNone, onCancel) { app ->
            set(app?.pkg); zv.save(); zv.invalidate(); refreshUi()
        }
    }

    fun showVault() {
        val hid = cfg.hidden()
        val apps = loadApps(this).filter { it.pkg in hid }
        if (apps.isEmpty()) { toast("No hidden apps"); return }
        showAppList("Hidden apps", apps, false, {}) { app ->
            if (app != null) {
                AlertDialog.Builder(this).setTitle(app.label).setItems(arrayOf("Open", "Unhide")) { _, i ->
                    if (i == 0) launchPkg(app.pkg, "list") else { cfg.setHidden(cfg.hidden() - app.pkg); toast("Unhidden") }
                }.show()
            }
        }
    }

    // ---------- looks (presets) ----------
    private val presetKeys = listOf("bg_mode", "bg_color", "bg_dim", "fx", "z_vis", "z_color", "z_alpha", "dark", "accent", "dots_on")
    private val presetPrefs by lazy { getSharedPreferences("presets", 0) }

    fun presetNames(): List<String> = presetPrefs.all.keys.sorted()

    fun savePreset(name: String) {
        val c = JSONObject()
        for (k in presetKeys) cfg.raw(k)?.let { c.put(k, it) }
        val o = JSONObject().put("look", look.toJson()).put("cfg", c)
        presetPrefs.edit().putString(name, o.toString()).apply()
    }

    fun deletePreset(name: String) { presetPrefs.edit().remove(name).apply() }

    fun applyPreset(name: String) {
        val s = presetPrefs.getString(name, null) ?: return
        try {
            val o = JSONObject(s)
            look.fromJson(o.getJSONObject("look"))
            var maxP = 0
            for (z in zv.zones) if (z.page > maxP) maxP = z.page
            for (w in look.widgets) if (w.page > maxP) w.page = maxP
            look.pages.keys.filter { it > maxP }.forEach { look.pages.remove(it) }
            val c = o.getJSONObject("cfg")
            val ks = c.keys()
            while (ks.hasNext()) { val k = ks.next(); cfg.putAny(k, c.get(k)) }
            look.save(); applyConfig(); zv.invalidate()
        } catch (e: Exception) { toast("Could not apply look") }
    }

    private fun checkAuto() {
        if (!cfg.b("auto_on", false)) return
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val s = cfg.i("auto_start", 22); val e = cfg.i("auto_end", 6)
        val night = if (s > e) (hr >= s || hr < e) else (hr in s until e)
        val name = cfg.s(if (night) "p_night" else "p_day", "")
        if (name.isNotEmpty() && name != lastAuto) { lastAuto = name; applyPreset(name) }
    }

    // ---------- backup ----------
    private val files = listOf("zones", "cfg", "gestures", "look", "presets", "stats")

    fun exportBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/json").putExtra(Intent.EXTRA_TITLE, "zonex-backup.json")
        startActivityForResult(i, 101)
    }

    fun importBackup() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        startActivityForResult(i, 102)
    }

    private fun dump(name: String): JSONObject {
        val o = JSONObject()
        for ((k, v) in getSharedPreferences(name, 0).all) {
            if (name == "cfg" && k.startsWith("pin_")) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> { val a = JSONArray(); v.forEach { a.put(it.toString()) }; e.put("t", "ss").put("v", a) }
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    private fun restore(name: String, o: JSONObject) {
        val sp = getSharedPreferences(name, 0)
        val ed = sp.edit()
        for (k in sp.all.keys) if (!(name == "cfg" && k.startsWith("pin_"))) ed.remove(k)
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            if (name == "cfg" && k.startsWith("pin_")) continue
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "ss" -> {
                    val a = e.getJSONArray("v"); val st = HashSet<String>()
                    for (i in 0 until a.length()) st.add(a.getString(i))
                    ed.putStringSet(k, st)
                }
            }
        }
        ed.commit()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode in 201..203) { onWidgetResult(requestCode, resultCode); return }
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        try {
            if (requestCode == 101) {
                val root = JSONObject()
                for (f in files) root.put(f, dump(f))
                contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray()) }
                toast("Backup saved")
            } else if (requestCode == 102) {
                val txt = contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: return
                val root = JSONObject(txt)
                for (f in files) root.optJSONObject(f)?.let { restore(f, it) }
                recreate()
            }
        } catch (e: Exception) { toast("Backup failed") }
    }

    fun wipeAll() {
        for (n in look.natives.toList()) { try { host.deleteAppWidgetId(n.id) } catch (e: Exception) { } }
        getSharedPreferences("appw", 0).edit().clear().commit()
        for (f in files) getSharedPreferences(f, 0).edit().clear().commit()
        recreate()
    }

    // ---------- native Android app widgets ----------
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private var reconfId = -1

    /** Step 1: allocate a widget id and bind it to the chosen provider (asks the user if Android requires it). */
    fun addAppWidget(info: AppWidgetProviderInfo) {
        if (pendingId != -1) cancelPending()
        val id = host.allocateAppWidgetId()
        pendingId = id; pendingInfo = info
        var bound = false
        try { bound = awm.bindAppWidgetIdIfAllowed(id, info.provider) } catch (e: Exception) { }
        if (bound) { afterBind(); return }
        val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
        try { startActivityForResult(i, 201) }
        catch (e: Exception) { cancelPending(); toast("This widget can't be added") }
    }

    /** Step 2: run the widget's own configuration screen if it has one, otherwise place it. */
    private fun afterBind() {
        val info = pendingInfo ?: return
        if (info.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, pendingId, 0, 202, null)
            } catch (e: Exception) { cancelPending(); toast("This widget's setup can't be opened") }
        } else placeNative(info)
    }

    /** Step 3: create the widget on the current screen, show it and save it. */
    private fun placeNative(info: AppWidgetProviderInfo) {
        val dm = resources.displayMetrics
        val d = dm.density
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        val w = info.minWidth.toFloat().coerceIn(80 * d, sw)
        val h = info.minHeight.toFloat().coerceIn(60 * d, sh * 0.8f)
        val l = ((sw - w) / 2f).coerceAtLeast(0f)
        val t = (sh * 0.3f - h / 2f).coerceAtLeast(60 * d)
        val n = NativeWidget(l, t, l + w, t + h, zv.cur(), pendingId, info.provider.flattenToString())
        n.applyInfo(info)
        pendingId = -1; pendingInfo = null
        look.natives.add(n)
        nativeLayer.add(n, makeNativeView(n))
        look.save()
        advanced.close()
        zv.setEditMode(true)
        zv.selBox = n
        refreshUi()
        zv.invalidate()
    }

    private fun cancelPending() {
        if (pendingId != -1) { try { host.deleteAppWidgetId(pendingId) } catch (e: Exception) { } }
        pendingId = -1; pendingInfo = null
    }

    private fun onWidgetResult(code: Int, result: Int) {
        when (code) {
            201 -> if (result == RESULT_OK) afterBind() else cancelPending()
            202 -> {
                val info = pendingInfo
                if (result == RESULT_OK && info != null) placeNative(info) else cancelPending()
            }
            203 -> { val id = reconfId; reconfId = -1; if (id != -1) rebuildNative(id) }
        }
    }

    /** Builds the real AppWidgetHostView (or a placeholder if the provider app is gone). */
    private fun makeNativeView(n: NativeWidget): View {
        val info = try { awm.getAppWidgetInfo(n.id) } catch (e: Exception) { null }
        if (info == null) {
            return TextView(this).apply {
                text = "Widget unavailable\n(its app was removed or is updating)"
                textSize = 13f; gravity = Gravity.CENTER
                setTextColor(0xFFE6E8EC.toInt()); setBackgroundColor(0x66000000)
            }
        }
        n.applyInfo(info)
        val hv = host.createView(this, n.id, info)
        hv.post { pushSize(n) }
        return hv
    }

    fun rebuildNative(id: Int) {
        val n = look.natives.firstOrNull { it.id == id } ?: return
        nativeLayer.replace(n, makeNativeView(n))
    }

    /** Tells the widget its new size (in dp) so it can pick the right layout. */
    private fun pushSize(n: NativeWidget) {
        val item = nativeLayer.items.firstOrNull { it.n === n } ?: return
        val hv = item.view as? AppWidgetHostView ?: return
        val d = resources.displayMetrics.density
        val w = ((n.r - n.l) / d).toInt(); val h = ((n.b - n.t) / d).toInt()
        try { hv.updateAppWidgetSize(null, w, h, w, h) } catch (e: Exception) { }
    }

    private fun canReconfigure(n: NativeWidget): Boolean {
        if (Build.VERSION.SDK_INT < 28) return false
        val info = try { awm.getAppWidgetInfo(n.id) } catch (e: Exception) { null } ?: return false
        return info.configure != null && (info.widgetFeatures and AppWidgetProviderInfo.WIDGET_FEATURE_RECONFIGURABLE) != 0
    }

    private fun configureNative(n: NativeWidget) {
        reconfId = n.id
        try { host.startAppWidgetConfigureActivityForResult(this, n.id, 0, 203, null) }
        catch (e: Exception) { reconfId = -1; toast("Can't open this widget's setup") }
    }

    // ---------- misc ----------
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        applyBackground()
    }

    private fun applyBackground() {
        if (cfg.i("bg_mode", 0) == 1) {
            window.setBackgroundDrawable(ColorDrawable(cfg.color("bg_color", 9))); return
        }
        try {
            val wd: Drawable? = WallpaperManager.getInstance(this).drawable
            if (wd != null) { window.setBackgroundDrawable(wd); return }
        } catch (e: Exception) { }
        window.setBackgroundDrawable(ColorDrawable(Color.parseColor("#1B2733")))
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            sb!!.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) { toast("Can't open notifications on this phone") }
    }

    override fun onBackPressed() {
        when {
            picker.visibility == View.VISIBLE -> picker.close()
            editor.visibility == View.VISIBLE -> editor.close()
            advanced.isOpen -> advanced.back()
            recorder.visibility == View.VISIBLE -> recorder.visibility = View.GONE
            settings.visibility == View.VISIBLE -> settings.visibility = View.GONE
            drawer.isOpen -> drawer.close()
            zv.edit -> zv.setEditMode(false)
        }
    }
}
