package com.example.tapzones

import kotlin.math.abs

class Tf(var tx: Float = 0f, var sx: Float = 1f, var sy: Float = 1f, var ry: Float = 0f,
         var rz: Float = 0f, var a: Float = 1f, var px: Float = 0f, var py: Float = 0f)

object Fx {
    val NAMES = listOf("Normal", "Cube", "Zoom", "Fade", "Rotate", "Flip", "Stack", "Depth", "Accordion")

    // p = page position relative to the current scroll (0 = fully shown, -1 = left, 1 = right)
    fun tf(e: Int, p: Float, w: Float, h: Float): Tf {
        val t = Tf(px = w / 2, py = h / 2)
        val ap = abs(p)
        when (e) {
            1 -> { t.tx = p * w; t.px = if (p < 0) w else 0f; t.ry = 90f * p }
            2 -> { t.tx = p * w; val s = 1f - 0.3f * ap; t.sx = s; t.sy = s; t.a = 1f - 0.6f * ap }
            3 -> { t.a = 1f - ap }
            4 -> { t.tx = p * w; t.rz = -15f * p; t.py = h }
            5 -> { t.ry = -180f * p; t.a = if (ap < 0.5f) 1f else 0f }
            6 -> if (p <= 0f) t.tx = p * w else { val s = 1f - 0.15f * p; t.sx = s; t.sy = s; t.a = 1f - 0.5f * p }
            7 -> if (p <= 0f) t.tx = p * w else { val s = 0.75f + 0.25f * (1f - p); t.sx = s; t.sy = s; t.a = 1f - p }
            8 -> { t.tx = p * w; t.px = if (p < 0) 0f else w; t.sx = 1f - ap }
            else -> t.tx = p * w
        }
        return t
    }
}
