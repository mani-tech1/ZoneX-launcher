package com.example.tapzones

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class SettingsPanel(private val a: Activity, private val cfg: Cfg,
                    private val store: GestureStore,
                    private val onApply: () -> Unit,
                    private val onResetZones: () -> Unit,
                    private val onAddGesture: () -> Unit) : FrameLayout(a) {
    var onClose: (() -> Unit)? = null
    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private var th = Th(true)
    private var accent = 0
    private val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val scroll = ScrollView(a)
    private val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(40)) }

    init {
        isClickable = true
        visibility = View.GONE
        scroll.addView(col)
        addView(box, LayoutParams(-1, -1))
    }

    private fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(a).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(24), dp(26), dp(24))
            flat(th, 22)
        }
        c.addView(tv(title, 16f, accent, true))
        col.addView(c, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(4), dp(8), dp(4)) })
        return c
    }

    private fun ask(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(a).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> ok() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toggle(c: LinearLayout, label: String, key: String, def: Boolean) {
        val on = cfg.b(key, def)
        val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(2)) }
        row.addView(tv(label, 15f, th.text), LinearLayout.LayoutParams(0, -2, 1f))
        val t = tv(if (on) "ON" else "OFF", 13f, if (on) accent else th.sub, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(12), dp(24), dp(12))
            flat(th, 14, on, if (on) accent else 0)
            setOnClickListener { cfg.set(key, !on); onApply(); rebuild() }
        }
        row.addView(t)
        c.addView(row)
    }

    private fun choice(c: LinearLayout, label: String, key: String, def: Int, opts: List<String>, vals: List<Int>) {
        c.addView(tv(label, 15f, th.text).apply { setPadding(0, dp(12), 0, dp(2)) })
        val row = LinearLayout(a)
        val cur = cfg.i(key, def)
        opts.forEachIndexed { i, o ->
            val sel = vals[i] == cur
            val chip = tv(o, 13f, if (sel) accent else th.sub, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(12), dp(18), dp(12))
                flat(th, 14, sel, if (sel) accent else 0)
                setOnClickListener { cfg.set(key, vals[i]); onApply(); rebuild() }
            }
            row.addView(chip, LinearLayout.LayoutParams(-2, -2))
        }
        c.addView(row)
    }

    private fun slider(c: LinearLayout, label: String, key: String, def: Int, min: Int, max: Int, unit: String) {
        val lab = tv("$label: ${cfg.i(key, def)}$unit", 15f, th.text).apply { setPadding(0, dp(12), 0, 0) }
        val sb = SeekBar(a)
        sb.max = max - min
        sb.progress = cfg.i(key, def) - min
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                val v = p + min
                cfg.set(key, v); lab.text = "$label: $v$unit"; onApply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        c.addView(lab)
        c.addView(sb, LinearLayout.LayoutParams(-1, -2))
    }

    private fun colors(c: LinearLayout, label: String, key: String, def: Int) {
        c.addView(tv(label, 15f, th.text).apply { setPadding(0, dp(12), 0, dp(4)) })
        val cur = cfg.i(key, def)
        PALETTE.indices.chunked(5).forEach { grp ->
            val row = LinearLayout(a)
            grp.forEach { i ->
                val sw = View(a)
                sw.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(PALETTE[i])
                    setStroke(if (i == cur) dp(3) else dp(1), if (i == cur) th.text else th.sub)
                }
                sw.setOnClickListener { cfg.set(key, i); onApply(); rebuild() }
                row.addView(sw, LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(dp(4), dp(6), dp(12), dp(6)) })
            }
            c.addView(row)
        }
    }

    private fun button(c: LinearLayout, text: String, onClick: () -> Unit) {
        val b = tv(text, 14f, th.text, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(14), dp(20), dp(14))
            flat(th, 16)
            setOnClickListener { onClick() }
        }
        c.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    fun rebuild() {
        th = Th(cfg.b("dark", true)); accent = cfg.color("accent", 1)
        setBackgroundColor(th.base)
        val sy = scroll.scrollY
        box.removeAllViews(); col.removeAllViews()

        val head = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(32), dp(12), dp(4)) }
        head.addView(tv("Settings", 24f, th.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(tv("Close", 14f, accent, true).apply {
            setPadding(dp(24), dp(12), dp(24), dp(12)); flat(th, 16)
            setOnClickListener { onClose?.invoke() }
        })
        box.addView(head)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        var c = card("Appearance")
        toggle(c, "Dark theme", "dark", true)
        colors(c, "Accent color", "accent", 1)

        c = card("Clock")
        toggle(c, "Show clock", "clock_show", true)
        toggle(c, "24-hour format", "clock24", false)
        toggle(c, "Show seconds", "sec_show", false)
        toggle(c, "Show day and date", "date_show", true)
        toggle(c, "Show battery %", "batt_show", true)
        slider(c, "Size", "clock_size", 64, 30, 110, "")
        choice(c, "Position", "clock_pos", 0, listOf("Top", "Middle", "Bottom"), listOf(0, 1, 2))
        colors(c, "Clock color", "clock_color", 0)

        c = card("Tap zones")
        toggle(c, "Show zones always", "z_vis", false)
        colors(c, "Zone color", "z_color", 1)
        slider(c, "See-through level", "z_alpha", 25, 5, 60, "%")
        slider(c, "Double-tap speed", "dt_ms", 300, 150, 600, " ms")
        toggle(c, "Vibrate when app opens", "z_vib", true)
        button(c, "Delete all zones") { ask("Delete ALL zones?") { onResetZones() } }

        c = card("App list (swipe up)")
        toggle(c, "Swipe up to open", "dr_on", true)
        choice(c, "Columns", "dr_cols", 4, listOf("3", "4", "5"), listOf(3, 4, 5))
        slider(c, "Icon size", "dr_icon", 56, 36, 80, " dp")
        toggle(c, "Show app names", "dr_names", true)
        slider(c, "Background darkness", "dr_dim", 90, 40, 100, "%")
        button(c, "Show hidden apps again") {
            cfg.setHidden(emptySet()); Toast.makeText(a, "Done", Toast.LENGTH_SHORT).show()
        }

        c = card("Background")
        choice(c, "Type", "bg_mode", 0, listOf("Wallpaper", "Solid color"), listOf(0, 1))
        colors(c, "Solid color", "bg_color", 9)
        slider(c, "Dim", "bg_dim", 0, 0, 80, "%")

        c = card("Hold times")
        slider(c, "Hold for edit mode", "hold_edit", 1000, 500, 2000, " ms")
        slider(c, "Hold for settings", "hold_set", 5000, 2000, 8000, " ms")

        c = card("Screens")
        toggle(c, "Swipe left/right to change screens", "pg_on", true)
        button(c, "Movement type: " + Fx.NAMES[cfg.i("fx", 0).coerceIn(0, Fx.NAMES.size - 1)]) {
            AlertDialog.Builder(a).setTitle("Movement type")
                .setSingleChoiceItems(Fx.NAMES.toTypedArray(), cfg.i("fx", 0)) { dlg, i ->
                    cfg.set("fx", i); onApply(); dlg.dismiss(); rebuild()
                }.show()
        }
        slider(c, "Switch speed", "pg_ms", 280, 150, 500, " ms")
        toggle(c, "Show page dots", "dots_on", true)

        c = card("Draw gestures")
        toggle(c, "Draw shapes to open apps", "g_on", true)
        toggle(c, "Show the line while drawing", "g_show", true)
        colors(c, "Line color", "g_color", 1)
        choice(c, "Accuracy", "g_acc", 1, listOf("Strict", "Normal", "Relaxed"), listOf(0, 1, 2))
        toggle(c, "Swipe down for notifications", "sd_on", true)
        store.list.forEachIndexed { i, g ->
            val row = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            row.addView(tv("Shape " + (i + 1) + " opens " + appLabel(a, g.pkg), 14f, th.text), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv("Delete", 13f, th.sub, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(10), dp(18), dp(10)); flat(th, 14)
                setOnClickListener { ask("Delete this shape?") { store.remove(i); rebuild() } }
            })
            c.addView(row)
        }
        button(c, "+ Add gesture") { onAddGesture() }

        c = card("Reset")
        button(c, "Reset all settings") {
            ask("Reset all settings to default?") { cfg.resetAll(); onApply(); rebuild() }
        }
        scroll.post { scroll.scrollTo(0, sy) }
    }
}
