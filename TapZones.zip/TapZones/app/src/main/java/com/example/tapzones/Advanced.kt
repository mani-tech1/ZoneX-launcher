package com.example.tapzones

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class Bars(ctx: Context, private val data: IntArray, private val color: Int, private val textColor: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height - 16 * d
        val mx = maxOf(1, data.max())
        val bw = w / data.size
        for (i in data.indices) {
            p.color = color
            val bh = h * data[i] / mx
            c.drawRoundRect(i * bw + bw * 0.15f, h - bh, (i + 1) * bw - bw * 0.15f, h, 3 * d, 3 * d, p)
        }
        p.color = textColor; p.textSize = 10 * d; p.textAlign = Paint.Align.CENTER
        for (i in listOf(0, 6, 12, 18, 23)) c.drawText(i.toString(), i * bw + bw / 2, height.toFloat() - 2 * d, p)
    }
}

class AdvancedPanel(m: MainActivity) : PanelBase(m) {
    private val stack = ArrayList<Pair<String, (LinearLayout) -> Unit>>()
    private val box = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL }
    private val scroll = ScrollView(m)
    private val col = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), dp(40)) }
    private var range = 1
    val isOpen get() = visibility == View.VISIBLE

    init { isClickable = true; visibility = View.GONE; scroll.addView(col); addView(box, LayoutParams(-1, -1)) }

    fun open() {
        stack.clear()
        stack.add("Advanced mode" to { c: LinearLayout -> menu(c) })
        visibility = View.VISIBLE
        render(false)
    }

    fun close() { visibility = View.GONE; stack.clear() }

    fun back() { if (stack.size > 1) { stack.removeAt(stack.size - 1); render(false) } else close() }

    private fun push(title: String, b: (LinearLayout) -> Unit) { stack.add(title to b); render(false) }

    override fun refresh() = render(true)

    private fun render(keep: Boolean) {
        themeUp()
        val sy = scroll.scrollY
        box.removeAllViews(); col.removeAllViews()
        val head = LinearLayout(m).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(32), dp(12), dp(8)) }
        head.addView(tv(stack.last().first, 20f, th.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(chip(if (stack.size > 1) "Back" else "Close", true) { back() })
        box.addView(head)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        stack.last().second(col)
        scroll.post { scroll.scrollTo(0, if (keep) sy else 0) }
    }

    // ---------------- main menu ----------------
    private fun menu(c: LinearLayout) {
        note(c, "Everything here is optional. Take your time.")
        item(c, "Clocks and widgets", "Many clock styles, placed anywhere") { push("Clocks and widgets") { clocks(it) } }
        item(c, "Screen looks", "Background for each screen") { push("Screen looks") { looks(it) } }
        item(c, "Security", "PIN lock for layout and settings") { push("Security") { security(it) } }
        item(c, "Hidden apps vault", "Apps hidden from the list") { push("Hidden apps vault") { vault(it) } }
        item(c, "Usage stats", "What you open the most") { push("Usage stats") { statsScreen(it) } }
        item(c, "Looks and auto switch", "Save looks, switch day and night") { push("Looks and auto switch") { presets(it) } }
        item(c, "Backup and restore", "Save everything to a file") { push("Backup and restore") { backup(it) } }
    }

    // ---------------- clocks ----------------
    private fun nameOf(w: Widget) = if (w.type == 0) ClockStyles.NAMES[w.style.coerceIn(0, ClockStyles.NAMES.size - 1)]
        else if (w.type == 1) "Battery card" else "Date card"

    private fun clocks(c: LinearLayout) {
        note(c, "Tap one to customize. Move and resize them in edit mode (hold 1 second on the home screen).")
        m.look.widgets.forEach { w ->
            item(c, "Screen " + (w.page + 1) + " · " + nameOf(w), "Tap to customize") { m.editor.open(w) }
        }
        sec(c, "Add to the current screen")
        button(c, "+ Clock") { m.pickStyle { s -> m.zv.addWidget(0, s); refresh() } }
        button(c, "+ Battery card") { m.zv.addWidget(1, 0); refresh() }
        button(c, "+ Date card") { m.zv.addWidget(2, 0); refresh() }
    }

    // ---------------- screen looks ----------------
    private val MODES = listOf("Default (wallpaper)", "Solid color", "Gradient")

    private fun looks(c: LinearLayout) {
        note(c, "Choose a background for each screen.")
        for (i in 0 until m.zv.contentPages()) {
            item(c, "Screen " + (i + 1), MODES[m.look.page(i).mode.coerceIn(0, 2)]) { push("Screen " + (i + 1)) { pageLook(it, i) } }
        }
    }

    private fun pageLook(c: LinearLayout, i: Int) {
        val pl = m.look.page(i)
        button(c, "Background: " + MODES[pl.mode.coerceIn(0, 2)]) {
            pickList("Background", MODES, pl.mode) { pl.mode = it; m.zv.persistLook(); refresh() }
        }
        if (pl.mode >= 1) colorRow(c, if (pl.mode == 2) "Top color" else "Color", { pl.c1 }, { pl.c1 = it; m.zv.persistLook() })
        if (pl.mode == 2) colorRow(c, "Bottom color", { pl.c2 }, { pl.c2 = it; m.zv.persistLook() })
        slider(c, "Darken", { pl.dim }, { pl.dim = it; m.zv.persistLook() }, 0, 80, "%")
    }

    // ---------------- security ----------------
    private fun security(c: LinearLayout) {
        if (!cfg.hasPin()) {
            note(c, "Set a PIN to lock editing and settings. If you forget it, the only way back in is to erase all app data.")
            button(c, "Set PIN") { m.askNewPin { pin -> cfg.setPin(pin); refresh() } }
            return
        }
        toggle(c, "Lock edit mode", { cfg.b("lock_edit", false) }, { cfg.set("lock_edit", it) })
        toggle(c, "Lock settings", { cfg.b("lock_set", true) }, { cfg.set("lock_set", it) })
        toggle(c, "Lock advanced mode", { cfg.b("lock_adv", true) }, { cfg.set("lock_adv", it) })
        button(c, "Change PIN") {
            m.askPin("Current PIN", false) { cur ->
                if (cfg.checkPin(cur)) m.askNewPin { pin -> cfg.setPin(pin); refresh() }
                else Toast.makeText(m, "Wrong PIN", Toast.LENGTH_SHORT).show()
            }
        }
        button(c, "Remove PIN") {
            m.askPin("Current PIN", false) { cur ->
                if (cfg.checkPin(cur)) { cfg.setPin(null); refresh() }
                else Toast.makeText(m, "Wrong PIN", Toast.LENGTH_SHORT).show()
            }
        }
        note(c, "The PIN stops casual snooping. It is not strong security: the app can still be uninstalled.")
    }

    // ---------------- vault ----------------
    private fun vault(c: LinearLayout) {
        note(c, "Apps you hide from the swipe-up list (long-press an app there) are kept here. Hidden apps still work inside zones.")
        button(c, "View hidden apps (" + cfg.hidden().size + ")") { m.showVault() }
        val w = cfg.s("vault_word", "")
        button(c, "Secret word: " + (if (w.isEmpty()) "not set" else w)) {
            m.askText("Secret word", w) { t -> cfg.setS("vault_word", t.trim()); refresh() }
        }
        note(c, "Type the secret word into the search box of the app list to open the vault.")
    }

    // ---------------- stats ----------------
    private fun statsScreen(c: LinearLayout) {
        val st = m.stats
        val row = LinearLayout(m)
        listOf("Today", "7 days", "All time").forEachIndexed { i, s ->
            row.addView(chip(s, range == i) { range = i; refresh() }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        c.addView(row)
        val days = when (range) { 0 -> 1; 1 -> 7; else -> 0 }
        val top = st.top(days, 8)
        val total = st.top(days, 100000).sumOf { it.second }
        sec(c, "Opened through this launcher: $total")
        if (top.isEmpty()) note(c, "Nothing yet. Open some apps from zones, shapes or the app list.")
        val mx = if (top.isEmpty()) 1 else top[0].second
        top.forEach { (pkg, n) ->
            val r = LinearLayout(m).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(5), dp(6), dp(5)) }
            r.addView(tv(appLabel(m, pkg), 13f, th.text), LinearLayout.LayoutParams(dp(100), -2))
            val bar = View(m)
            bar.background = GradientDrawable().apply { cornerRadius = 5 * d; setColor(accent) }
            r.addView(bar, LinearLayout.LayoutParams(0, dp(10), n.toFloat()))
            if (mx > n) r.addView(View(m), LinearLayout.LayoutParams(0, dp(10), (mx - n).toFloat()))
            r.addView(tv(n.toString(), 12f, th.sub).apply { setPadding(dp(8), 0, 0, 0) })
            c.addView(r)
        }
        val src = st.sources()
        sec(c, "How you open apps (all time)")
        note(c, "Zones: " + src["zone"] + "   Shapes: " + src["shape"] + "   App list: " + src["list"])
        val hrs = st.hours()
        sec(c, "Busiest hours (all time)")
        c.addView(Bars(m, hrs, accent, th.sub), LinearLayout.LayoutParams(-1, dp(110)))
        val best = hrs.indices.maxByOrNull { hrs[it] } ?: 0
        if (hrs[best] > 0) note(c, "Busiest hour: " + best + ":00 to " + (best + 1) + ":00")
        button(c, "Reset stats") {
            AlertDialog.Builder(m).setMessage("Clear all usage stats?")
                .setPositiveButton("Clear") { _, _ -> st.reset(); refresh() }
                .setNegativeButton("Cancel", null).show()
        }
    }

    // ---------------- presets ----------------
    private fun presets(c: LinearLayout) {
        note(c, "A look is your clocks, screen backgrounds, colors and effect. Zones are not changed.")
        button(c, "Save current look") {
            m.askText("Name this look", "") { n -> if (n.isNotBlank()) { m.savePreset(n.trim()); refresh() } }
        }
        m.presetNames().forEach { n ->
            val tag = (if (cfg.s("p_day", "") == n) "  (day)" else "") + (if (cfg.s("p_night", "") == n) "  (night)" else "")
            item(c, n + tag, "Tap for options") {
                AlertDialog.Builder(m).setTitle(n)
                    .setItems(arrayOf("Apply now", "Use as day look", "Use as night look", "Delete")) { _, i ->
                        when (i) {
                            0 -> m.applyPreset(n)
                            1 -> cfg.setS("p_day", n)
                            2 -> cfg.setS("p_night", n)
                            else -> m.deletePreset(n)
                        }
                        refresh()
                    }.show()
            }
        }
        sec(c, "Auto switch")
        toggle(c, "Switch day and night automatically", { cfg.b("auto_on", false) }, { cfg.set("auto_on", it) })
        slider(c, "Night starts at", { cfg.i("auto_start", 22) }, { cfg.set("auto_start", it) }, 0, 23, ":00")
        slider(c, "Night ends at", { cfg.i("auto_end", 6) }, { cfg.set("auto_end", it) }, 0, 23, ":00")
    }

    // ---------------- backup ----------------
    private fun backup(c: LinearLayout) {
        note(c, "Saves zones, shapes, looks, settings and stats to a file you choose. The PIN is not included.")
        button(c, "Export backup") { m.exportBackup() }
        button(c, "Restore backup") {
            AlertDialog.Builder(m).setMessage("Restoring replaces your current zones and settings. Continue?")
                .setPositiveButton("Restore") { _, _ -> m.importBackup() }
                .setNegativeButton("Cancel", null).show()
        }
        sec(c, "Danger zone")
        button(c, "Erase all app data") {
            AlertDialog.Builder(m).setMessage("Erase ALL zones, shapes, looks, settings, stats and the PIN?")
                .setPositiveButton("Erase") { _, _ -> m.wipeAll() }
                .setNegativeButton("Cancel", null).show()
        }
    }
}

class WidgetEditor(m: MainActivity) : PanelBase(m) {
    private var w: Widget? = null
    private var preview: View? = null
    private val box = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL }
    private val scroll = ScrollView(m)
    private val col = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), dp(40)) }

    init { isClickable = true; visibility = View.GONE; scroll.addView(col); addView(box, LayoutParams(-1, -1)) }

    fun open(widget: Widget) { w = widget; visibility = View.VISIBLE; render(false) }
    fun close() { visibility = View.GONE; m.zv.persistLook() }

    override fun refresh() = render(true)
    override fun live() { m.zv.persistLook(); preview?.invalidate() }

    private fun render(keep: Boolean) {
        val wd = w ?: return
        themeUp()
        val sy = scroll.scrollY
        box.removeAllViews(); col.removeAllViews()
        val head = LinearLayout(m).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(32), dp(12), dp(8)) }
        head.addView(tv("Customize", 20f, th.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(chip("Done", true) { close() })
        box.addView(head)
        val pv = ClockPreview(m, wd) { m.zv.batt }
        preview = pv
        box.addView(pv, LinearLayout.LayoutParams(-1, dp(190)).apply { setMargins(dp(14), dp(4), dp(14), dp(8)) })
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val c = col
        if (wd.type == 0) {
            button(c, "Style: " + ClockStyles.NAMES[wd.style.coerceIn(0, ClockStyles.NAMES.size - 1)]) {
                m.pickStyle { s -> wd.style = s; ClockStyles.defaults(wd); ClockStyles.resize(wd, d); live(); refresh() }
            }
        }
        sec(c, "Colors")
        colorRow(c, "Main color", { wd.c1 }, { wd.c1 = it })
        colorRow(c, "Accent color", { wd.c2 }, { wd.c2 = it })
        colorRow(c, "Background / card color", { wd.cb }, { wd.cb = it })
        sec(c, "Options")
        if (wd.type == 0) {
            toggle(c, "24-hour time", { wd.h24 }, { wd.h24 = it })
            toggle(c, "Show seconds", { wd.sec }, { wd.sec = it })
            toggle(c, "Show AM / PM", { wd.ampm }, { wd.ampm = it })
            toggle(c, "Show date", { wd.date }, { wd.date = it })
            toggle(c, "Show battery %", { wd.batt }, { wd.batt = it })
        }
        toggle(c, "Text shadow", { wd.shadow }, { wd.shadow = it })
        slider(c, "Background opacity", { wd.alpha }, { wd.alpha = it }, 0, 100, "%")
        slider(c, "Line thickness", { wd.thick }, { wd.thick = it }, 1, 12, "")
        button(c, "Font: " + ClockStyles.FONTS[wd.font.coerceIn(0, ClockStyles.FONTS.size - 1)]) {
            pickList("Font", ClockStyles.FONTS, wd.font) { wd.font = it; live(); refresh() }
        }
        if (wd.type == 0 && (wd.style == 6 || wd.style == 11 || wd.style == 3)) {
            button(c, "Marks: " + ClockStyles.TICKS[wd.ticks.coerceIn(0, ClockStyles.TICKS.size - 1)]) {
                pickList("Marks", ClockStyles.TICKS, wd.ticks) { wd.ticks = it; live(); refresh() }
            }
        }
        note(c, "To move or resize it, use edit mode on the home screen.")
        button(c, "Delete this widget") {
            AlertDialog.Builder(m).setMessage("Delete this widget?")
                .setPositiveButton("Delete") { _, _ -> m.zv.deleteWidget(wd); close() }
                .setNegativeButton("Cancel", null).show()
        }
        scroll.post { scroll.scrollTo(0, if (keep) sy else 0) }
    }
}
