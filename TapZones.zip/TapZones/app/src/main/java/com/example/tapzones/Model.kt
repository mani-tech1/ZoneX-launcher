package com.example.tapzones

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

open class Box(var l: Float, var t: Float, var r: Float, var b: Float, var page: Int = 0)

class Zone(l: Float, t: Float, r: Float, b: Float,
           var dbl: String? = null, var sgl: String? = null, page: Int = 0, var lng: String? = null) : Box(l, t, r, b, page)

class Widget(l: Float, t: Float, r: Float, b: Float, page: Int = 0, var type: Int = 0, var style: Int = 5) : Box(l, t, r, b, page) {
    var c1 = 0
    var c2 = 1
    var cb = 9
    var h24 = false
    var sec = false
    var date = true
    var ampm = true
    var batt = false
    var alpha = 55
    var shadow = true
    var font = 1
    var thick = 4
    var ticks = 1

    fun toJson(): JSONObject = JSONObject()
        .put("l", l.toDouble()).put("t", t.toDouble()).put("r", r.toDouble()).put("b", b.toDouble())
        .put("pg", page).put("ty", type).put("st", style).put("c1", c1).put("c2", c2).put("cb", cb)
        .put("h24", h24).put("sec", sec).put("date", date).put("ampm", ampm).put("batt", batt)
        .put("al", alpha).put("sh", shadow).put("fo", font).put("th", thick).put("tk", ticks)

    companion object {
        fun from(o: JSONObject): Widget {
            val w = Widget(o.getDouble("l").toFloat(), o.getDouble("t").toFloat(),
                o.getDouble("r").toFloat(), o.getDouble("b").toFloat(),
                o.optInt("pg", 0), o.optInt("ty", 0), o.optInt("st", 5))
            w.c1 = o.optInt("c1", 0); w.c2 = o.optInt("c2", 1); w.cb = o.optInt("cb", 9)
            w.h24 = o.optBoolean("h24", false); w.sec = o.optBoolean("sec", false)
            w.date = o.optBoolean("date", true); w.ampm = o.optBoolean("ampm", true)
            w.batt = o.optBoolean("batt", false)
            w.alpha = o.optInt("al", 55); w.shadow = o.optBoolean("sh", true)
            w.font = o.optInt("fo", 1); w.thick = o.optInt("th", 4); w.ticks = o.optInt("tk", 1)
            return w
        }
    }
}

class PageLook(var mode: Int = 0, var c1: Int = 9, var c2: Int = 8, var dim: Int = 0) {
    fun toJson(): JSONObject = JSONObject().put("m", mode).put("a", c1).put("b", c2).put("d", dim)
}

class Look(ctx: Context) {
    private val p = ctx.getSharedPreferences("look", 0)
    val widgets = mutableListOf<Widget>()
    val pages = HashMap<Int, PageLook>()

    init { load() }

    fun isNew() = !p.contains("j")
    fun page(i: Int): PageLook = pages.getOrPut(i) { PageLook() }

    fun toJson(): JSONObject {
        val w = JSONArray()
        widgets.forEach { w.put(it.toJson()) }
        val pg = JSONObject()
        pages.forEach { (k, v) -> pg.put(k.toString(), v.toJson()) }
        return JSONObject().put("w", w).put("p", pg)
    }

    fun fromJson(o: JSONObject) {
        widgets.clear(); pages.clear()
        val w = o.optJSONArray("w")
        if (w != null) for (i in 0 until w.length()) widgets.add(Widget.from(w.getJSONObject(i)))
        val pg = o.optJSONObject("p")
        if (pg != null) {
            val ks = pg.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val j = pg.getJSONObject(k)
                pages[k.toInt()] = PageLook(j.optInt("m", 0), j.optInt("a", 9), j.optInt("b", 8), j.optInt("d", 0))
            }
        }
    }

    fun save() { p.edit().putString("j", toJson().toString()).apply() }

    private fun load() {
        val s = p.getString("j", null) ?: return
        try { fromJson(JSONObject(s)) } catch (e: Exception) { widgets.clear(); pages.clear() }
    }
}
