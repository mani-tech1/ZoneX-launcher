package com.example.tapzones

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class SurpriseView(a: Activity) : View(a) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var anim: ValueAnimator? = null

    init { visibility = GONE; isClickable = false }

    fun play(ms: Long) {
        anim?.cancel()
        visibility = VISIBLE
        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = ms
        va.addUpdateListener { t = it.animatedValue as Float; invalidate() }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { visibility = GONE }
        })
        anim = va
        va.start()
    }

    private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
        val env = sin(PI * t).toFloat().coerceIn(0f, 1f)
        c.drawColor(Color.argb((env * 190).toInt(), 8, 10, 20))
        p.style = Paint.Style.STROKE
        for (i in 0..2) {
            val tt = (t * 1.25f - i * 0.18f).coerceIn(0f, 1f)
            if (tt <= 0f || tt >= 1f) continue
            p.strokeWidth = (6 - i * 1.5f) * d
            p.color = Color.argb(((1f - tt) * 255).toInt(), 41, 182, 246)
            c.drawCircle(cx, cy, tt * h * 0.55f, p)
        }
        p.style = Paint.Style.FILL
        val pt = (t * 1.1f).coerceIn(0f, 1f)
        for (i in 0 until 28) {
            val ang = i * 2 * PI / 28
            val rr = pt * h * (0.18f + (i % 5) * 0.07f)
            p.color = withA(PALETTE[i % PALETTE.size], ((1f - pt) * 255).toInt())
            c.drawCircle(cx + cos(ang).toFloat() * rr, cy + sin(ang).toFloat() * rr, 4 * d * (1f - pt * 0.5f), p)
        }
        val ta = if (t < 0.2f) t / 0.2f else if (t > 0.8f) (1f - t) / 0.2f else 1f
        val sc = 0.7f + 0.3f * minOf(1f, t / 0.3f)
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        p.textSize = 34 * d * sc
        p.color = Color.argb((ta * 255).toInt(), 255, 255, 255)
        c.drawText("You found it!", cx, cy, p)
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.textSize = 15 * d
        p.color = Color.argb((ta * 255).toInt(), 41, 182, 246)
        c.drawText("Advanced mode unlocked", cx, cy + 34 * d, p)
    }
}
