package com.example.tapzones

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class App(val label: String, val pkg: String, val icon: Drawable)

fun loadApps(a: Activity): List<App> {
    val pm = a.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
        .filter { it.pkg != a.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

class DrawerPanel(private val a: Activity, private val cfg: Cfg,
                  private val onLaunch: (String) -> Unit,
                  private val onZone: (String) -> Unit) : FrameLayout(a) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private var th = Th(true)
    private var all = listOf<App>()
    private var shown = listOf<App>()
    val isOpen get() = visibility == View.VISIBLE

    private val ad = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val app = shown[p]
            val box = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
            }
            val sz = dp(cfg.i("dr_icon", 56))
            box.addView(ImageView(a).apply { setImageDrawable(app.icon) }, LinearLayout.LayoutParams(sz, sz))
            if (cfg.b("dr_names", true)) {
                box.addView(TextView(a).apply {
                    text = app.label; textSize = 12f; setTextColor(th.text)
                    maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0)
                })
            }
            return box
        }
    }

    init { isClickable = true; visibility = View.GONE }

    private fun refresh() {
        removeAllViews()
        th = Th(cfg.b("dark", true))
        val alpha = cfg.i("dr_dim", 90) * 255 / 100
        setBackgroundColor((th.base and 0xFFFFFF) or (alpha shl 24))
        val hid = cfg.hidden()
        all = loadApps(a).filter { it.pkg !in hid }
        shown = all

        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(30), dp(8), 0) }
        val bar = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(a).apply {
            hint = "Search apps"; isSingleLine = true
            setTextColor(th.text); setHintTextColor(th.sub)
            setPadding(dp(30), dp(14), dp(30), dp(14))
            flat(th, 26, true)
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim().lowercase()
                shown = all.filter { it.label.lowercase().contains(q) }
                ad.notifyDataSetChanged()
            }
        })
        val x = TextView(a).apply {
            text = "✕"; textSize = 18f; setTextColor(th.text); gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12)); flat(th, 22)
            setOnClickListener { close() }
        }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(x, LinearLayout.LayoutParams(-2, -2))
        box.addView(bar)

        val grid = GridView(a)
        grid.numColumns = cfg.i("dr_cols", 4)
        grid.adapter = ad
        grid.selector = android.graphics.drawable.ColorDrawable(0)
        grid.setOnItemClickListener { _, _, p, _ -> onLaunch(shown[p].pkg) }
        grid.setOnItemLongClickListener { _, _, p, _ -> menu(shown[p]); true }
        box.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        addView(box, LayoutParams(-1, -1))
    }

    private fun menu(app: App) {
        AlertDialog.Builder(a).setTitle(app.label)
            .setItems(arrayOf("Hide from this list", "Make a zone for this app")) { _, i ->
                if (i == 0) {
                    cfg.setHidden(cfg.hidden() + app.pkg)
                    all = all.filter { it.pkg != app.pkg }; shown = shown.filter { it.pkg != app.pkg }
                    ad.notifyDataSetChanged()
                } else onZone(app.pkg)
            }.show()
    }

    fun open() {
        refresh()
        visibility = View.VISIBLE
        translationY = resources.displayMetrics.heightPixels.toFloat()
        animate().translationY(0f).setDuration(220).start()
    }

    fun close() {
        if (!isOpen) return
        animate().translationY(resources.displayMetrics.heightPixels.toFloat()).setDuration(200)
            .withEndAction { visibility = View.GONE }.start()
    }
}
