package com.example.tapzones

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.math.abs

class App(val label: String, val pkg: String, val icon: Drawable) {
    val lower = label.lowercase()
}

fun loadApps(a: Activity): List<App> {
    val pm = a.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
        .filter { it.pkg != a.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

class DrawerPanel(private val a: Activity, private val cfg: Cfg,
                  private val onLaunch: (String) -> Unit,
                  private val onZone: (String) -> Unit,
                  private val onVault: () -> Unit) : FrameLayout(a) {
    private class VH(val icon: ImageView, val label: TextView?)

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val screenH get() = resources.displayMetrics.heightPixels.toFloat()
    private val slop = ViewConfiguration.get(a).scaledTouchSlop
    private val imm = a.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private var th = Th(true)
    private var cache: List<App>? = null
    private var loading = false
    private var all = listOf<App>()
    private var shown = listOf<App>()
    private var query = ""
    private var closing = false
    private var launching = false
    private var dragOpening = false
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var dragStartY = 0f
    private var lastScroll = 0L
    private var sig = ""

    // tiny velocity estimator based on raw screen coordinates (the panel itself moves while dragging)
    private val sampleT = LongArray(6)
    private val sampleY = FloatArray(6)
    private var sampleN = 0

    private lateinit var et: EditText
    private lateinit var grid: GridView
    private lateinit var emptyTv: TextView
    private lateinit var xBtn: TextView

    val isOpen get() = visibility == View.VISIBLE

    private val ad = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val v = cv ?: buildItem()
            val vh = v.tag as VH
            val app = shown[p]
            vh.icon.setImageDrawable(app.icon)
            vh.label?.text = app.label
            return v
        }
    }

    private val autoRun = Runnable {
        if (isOpen && !closing && !launching && query.isNotEmpty() && shown.size == 1) launchApp(shown[0])
    }

    init {
        isClickable = true
        visibility = View.GONE
        build()
    }

    // ---------------- views ----------------
    private fun itemH() = dp(cfg.i("dr_icon", 56)) + dp(20) + (if (cfg.b("dr_names", true)) dp(22) else 0)

    private fun buildItem(): View {
        val sz = dp(cfg.i("dr_icon", 56))
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, itemH())
        }
        val iv = ImageView(a)
        box.addView(iv, LinearLayout.LayoutParams(sz, sz))
        var tv: TextView? = null
        if (cfg.b("dr_names", true)) {
            tv = TextView(a).apply {
                textSize = 12f; setTextColor(th.text)
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0)
            }
            box.addView(tv)
        }
        box.tag = VH(iv, tv)
        return box
    }

    private fun build() {
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(30), dp(8), 0) }
        val bar = LinearLayout(a).apply { gravity = Gravity.CENTER_VERTICAL }
        et = EditText(a).apply {
            hint = "Search apps"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(30), dp(14), dp(30), dp(14))
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun onTextChanged(s: CharSequence?, x: Int, y: Int, z: Int) {}
            override fun afterTextChanged(s: Editable?) { onQueryChanged(s.toString()) }
        })
        et.setOnEditorActionListener { _, actionId, ev ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)) {
                onSearchKey(); true
            } else false
        }
        xBtn = TextView(a).apply {
            text = "✕"; textSize = 18f; gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            setOnClickListener { close() }
        }
        bar.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(xBtn, LinearLayout.LayoutParams(-2, -2))
        box.addView(bar)

        grid = GridView(a).apply {
            selector = ColorDrawable(0)
            isScrollingCacheEnabled = false
            adapter = ad
        }
        grid.setOnItemClickListener { _, _, p, _ ->
            if (SystemClock.uptimeMillis() - lastScroll >= 80 && p < shown.size) launchApp(shown[p])
        }
        grid.setOnItemLongClickListener { _, _, p, _ -> if (p < shown.size) menu(shown[p]); true }
        grid.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, state: Int) {
                if (state != AbsListView.OnScrollListener.SCROLL_STATE_IDLE) lastScroll = SystemClock.uptimeMillis()
            }
            override fun onScroll(v: AbsListView?, first: Int, visible: Int, total: Int) {}
        })
        emptyTv = TextView(a).apply {
            textSize = 14f; gravity = Gravity.CENTER
            setPadding(dp(24), 0, dp(24), 0)
            visibility = View.GONE
        }
        val gb = FrameLayout(a)
        gb.addView(grid, LayoutParams(-1, -1))
        gb.addView(emptyTv, LayoutParams(-1, -2, Gravity.CENTER))
        box.addView(gb, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })
        addView(box, LayoutParams(-1, -1))
    }

    // ---------------- data (cached, refreshed in the background) ----------------
    fun preload() {
        if (loading) return
        loading = true
        Thread {
            val l = try { loadApps(a) } catch (e: Exception) { null }
            a.runOnUiThread {
                loading = false
                if (l != null) {
                    val old = cache
                    cache = l
                    if (old == null || old.map { it.pkg } != l.map { it.pkg }) {
                        refreshHidden()
                        if (isOpen) applyFilter(false)
                    }
                }
            }
        }.start()
    }

    private fun refreshHidden() {
        val hid = cfg.hidden()
        all = (cache ?: emptyList()).filter { it.pkg !in hid }
    }

    // ---------------- search ----------------
    private fun onQueryChanged(raw: String) {
        removeCallbacks(autoRun)
        val q = raw.trim().lowercase()
        val sw = cfg.s("vault_word", "").trim().lowercase()
        if (sw.isNotEmpty() && q == sw) { et.setText(""); onVault(); return }
        query = q
        applyFilter(true)
        // a single match launches by itself after a short pause; any further typing cancels it
        if (q.isNotEmpty() && shown.size == 1 && !closing && !launching) postDelayed(autoRun, 500)
    }

    private fun applyFilter(resetScroll: Boolean) {
        shown = if (query.isEmpty()) all else all.filter { it.lower.startsWith(query) }
        ad.notifyDataSetChanged()
        if (resetScroll) grid.setSelection(0)
        if (shown.isEmpty() && query.isNotEmpty()) {
            emptyTv.text = "No app found for \u201C" + et.text.toString().trim() + "\u201D\nPress Search on the keyboard to search Google"
            emptyTv.visibility = View.VISIBLE
        } else emptyTv.visibility = View.GONE
    }

    private fun onSearchKey() {
        removeCallbacks(autoRun)
        val raw = et.text.toString().trim()
        if (raw.isEmpty()) return
        if (shown.isNotEmpty()) launchApp(shown[0]) else googleSearch(raw)
    }

    private fun googleSearch(q: String) {
        if (launching || closing) return
        var ok = false
        try {
            a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            ok = true
        } catch (e: Exception) { }
        if (!ok) {
            try {
                a.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q))
                ok = true
            } catch (e: Exception) { }
        }
        if (ok) { launching = true; close() } else Toast.makeText(a, "No app can search the web", Toast.LENGTH_SHORT).show()
    }

    private fun launchApp(app: App) {
        if (launching || closing) return
        launching = true
        removeCallbacks(autoRun)
        hideKb()
        onLaunch(app.pkg)
    }

    private fun showKb() {
        et.requestFocus()
        imm.showSoftInput(et, 0)
    }

    private fun hideKb() { imm.hideSoftInputFromWindow(et.windowToken, 0) }

    private fun menu(app: App) {
        hideKb()
        AlertDialog.Builder(a).setTitle(app.label)
            .setItems(arrayOf("Hide from this list", "Make a zone for this app")) { _, i ->
                if (i == 0) {
                    cfg.setHidden(cfg.hidden() + app.pkg)
                    all = all.filter { it.pkg != app.pkg }
                    applyFilter(false)
                } else onZone(app.pkg)
            }.show()
    }

    // ---------------- open / close with finger-following animation ----------------
    private fun prepare() {
        th = Th(cfg.b("dark", true))
        val alpha = cfg.i("dr_dim", 90) * 255 / 100
        setBackgroundColor((th.base and 0xFFFFFF) or (alpha shl 24))
        et.setTextColor(th.text); et.setHintTextColor(th.sub); et.flat(th, 26, true)
        xBtn.setTextColor(th.text); xBtn.flat(th, 22)
        emptyTv.setTextColor(th.sub)
        val s = cfg.i("dr_cols", 4).toString() + "|" + cfg.i("dr_icon", 56) + "|" + cfg.b("dr_names", true) + "|" + th.dark
        if (s != sig) { sig = s; grid.numColumns = cfg.i("dr_cols", 4); grid.adapter = ad }
        launching = false; closing = false
        if (cache == null) cache = loadApps(a)
        refreshHidden()
        et.setText("")
        query = ""
        applyFilter(true)
        preload()
    }

    private fun settle(openIt: Boolean, vy: Float = 0f) {
        val target = if (openIt) 0f else screenH
        val dist = abs(translationY - target)
        var dur = (150 + 170 * dist / screenH).toLong()
        if (vy > 0f) dur = (dist / vy * 1000f).toLong().coerceIn(110L, 320L)
        closing = !openIt
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        animate().translationY(target).alpha(if (openIt) 1f else 0f)
            .setDuration(dur).setInterpolator(DecelerateInterpolator(1.3f))
            .withEndAction {
                setLayerType(View.LAYER_TYPE_NONE, null)
                translationY = 0f; alpha = 1f
                if (openIt) showKb() else { visibility = View.GONE; closing = false }
            }.start()
    }

    fun open() {
        animate().cancel()
        dragOpening = false
        prepare()
        translationY = screenH; alpha = 0f
        visibility = View.VISIBLE
        settle(true)
    }

    fun close() {
        if (!isOpen || closing) return
        removeCallbacks(autoRun)
        hideKb()
        settle(false, 0f)
    }

    /** Called while the finger drags up on the home screen: the drawer follows the finger. */
    fun dragOpen(offset: Float) {
        if (!dragOpening) {
            animate().cancel()
            prepare()
            translationY = screenH; alpha = 0f
            visibility = View.VISIBLE
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            dragOpening = true
        }
        translationY = (screenH - offset).coerceIn(0f, screenH)
        alpha = (offset / (screenH * 0.45f)).coerceIn(0f, 1f)
    }

    /** Finger lifted (or the gesture was cancelled/reversed) after dragOpen. */
    fun endOpenDrag(vy: Float, cancel: Boolean) {
        if (!dragOpening) return
        dragOpening = false
        val offset = screenH - translationY
        val up = !cancel && (vy < -1000f * d || (vy <= 1000f * d && offset > screenH * 0.3f))
        settle(up, abs(vy))
    }

    // ---------------- swipe down to close (finger-following) ----------------
    private fun addSample(y: Float, t: Long) {
        if (sampleN == sampleT.size) {
            for (i in 1 until sampleT.size) { sampleT[i - 1] = sampleT[i]; sampleY[i - 1] = sampleY[i] }
            sampleN--
        }
        sampleT[sampleN] = t; sampleY[sampleN] = y; sampleN++
    }

    private fun velocityY(): Float {
        if (sampleN < 2) return 0f
        val dt = sampleT[sampleN - 1] - sampleT[0]
        return if (dt <= 0L) 0f else (sampleY[sampleN - 1] - sampleY[0]) / dt * 1000f
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; dragging = false
                sampleN = 0; addSample(e.rawY, e.eventTime)
            }
            MotionEvent.ACTION_MOVE -> {
                addSample(e.rawY, e.eventTime)
                val dy = e.rawY - downY; val dx = e.rawX - downX
                if (!dragging && !closing && !dragOpening && dy > slop && dy > abs(dx) * 1.5f && !grid.canScrollVertically(-1)) {
                    dragging = true; dragStartY = e.rawY
                    removeCallbacks(autoRun)
                    hideKb()
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; dragging = false
                sampleN = 0; addSample(e.rawY, e.eventTime)
            }
            MotionEvent.ACTION_MOVE -> {
                addSample(e.rawY, e.eventTime)
                val dy = e.rawY - downY; val dx = e.rawX - downX
                if (!dragging && !closing && !dragOpening && dy > slop && dy > abs(dx) * 1.5f && !grid.canScrollVertically(-1)) {
                    dragging = true; dragStartY = e.rawY
                    removeCallbacks(autoRun)
                    hideKb()
                }
                if (dragging) {
                    val ty = (e.rawY - dragStartY).coerceAtLeast(0f)
                    translationY = ty
                    alpha = 1f - 0.7f * (ty / screenH)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    val vy = velocityY()
                    val closeIt = e.actionMasked == MotionEvent.ACTION_UP &&
                        (vy > 1000f * d || (vy >= -1000f * d && translationY > screenH * 0.28f))
                    settle(!closeIt, abs(vy))
                }
            }
        }
        return true
    }
}
