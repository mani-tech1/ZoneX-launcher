package com.example.tapzones

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

val PALETTE = intArrayOf(
    0xFFFFFFFF.toInt(), 0xFF29B6F6.toInt(), 0xFF66BB6A.toInt(), 0xFFFFEE58.toInt(), 0xFFFFA726.toInt(),
    0xFFEF5350.toInt(), 0xFFEC407A.toInt(), 0xFFAB47BC.toInt(), 0xFF5C6BC0.toInt(), 0xFF000000.toInt()
)

class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", 0)
    fun b(k: String, d: Boolean) = p.getBoolean(k, d)
    fun i(k: String, d: Int) = p.getInt(k, d)
    fun s(k: String, d: String): String = p.getString(k, d) ?: d
    fun set(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
    fun set(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun setS(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun raw(k: String): Any? = p.all[k]
    fun putAny(k: String, v: Any) {
        when (v) { is Boolean -> set(k, v); is Int -> set(k, v); is String -> setS(k, v) }
    }
    fun color(k: String, d: Int): Int = PALETTE[i(k, d).coerceIn(0, PALETTE.size - 1)]
    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet()) ?: emptySet()
    fun setHidden(s: Set<String>) { p.edit().putStringSet("hidden", HashSet(s)).apply() }

    fun resetAll() {
        val h = p.getString("pin_h", null); val sl = p.getString("pin_s", null); val hid = hidden()
        val e = p.edit().clear()
        if (h != null) { e.putString("pin_h", h); e.putString("pin_s", sl) }
        e.putStringSet("hidden", HashSet(hid))
        e.apply()
    }

    fun hasPin() = p.getString("pin_h", null) != null
    private fun hash(salt: String, pin: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }
    fun setPin(pin: String?) {
        if (pin == null) { p.edit().remove("pin_h").remove("pin_s").apply(); return }
        val b = ByteArray(8); SecureRandom().nextBytes(b)
        val salt = b.joinToString("") { "%02x".format(it) }
        p.edit().putString("pin_s", salt).putString("pin_h", hash(salt, pin)).apply()
    }
    fun checkPin(pin: String): Boolean {
        val h = p.getString("pin_h", null) ?: return true
        return hash(p.getString("pin_s", "") ?: "", pin) == h
    }
}
