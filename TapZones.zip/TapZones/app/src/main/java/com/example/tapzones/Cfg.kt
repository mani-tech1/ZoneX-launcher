package com.example.tapzones

import android.content.Context

val PALETTE = intArrayOf(
    0xFFFFFFFF.toInt(), 0xFF29B6F6.toInt(), 0xFF66BB6A.toInt(), 0xFFFFEE58.toInt(), 0xFFFFA726.toInt(),
    0xFFEF5350.toInt(), 0xFFEC407A.toInt(), 0xFFAB47BC.toInt(), 0xFF5C6BC0.toInt(), 0xFF000000.toInt()
)

class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", 0)
    fun b(k: String, d: Boolean) = p.getBoolean(k, d)
    fun i(k: String, d: Int) = p.getInt(k, d)
    fun set(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
    fun set(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun color(k: String, d: Int): Int = PALETTE[i(k, d).coerceIn(0, PALETTE.size - 1)]
    fun hidden(): Set<String> = p.getStringSet("hidden", emptySet()) ?: emptySet()
    fun setHidden(s: Set<String>) { p.edit().putStringSet("hidden", HashSet(s)).apply() }
    fun resetAll() { p.edit().clear().apply() }
}
