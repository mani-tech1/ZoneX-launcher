package com.example.tapzones

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetProviderInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

const val WIDGET_HOST_ID = 0x5A4F

/** The AppWidgetHost for ZoneX. Rebuilds a widget view when its provider app is updated. */
class ZHost(private val m: MainActivity) : AppWidgetHost(m, WIDGET_HOST_ID) {
    override fun onProviderChanged(appWidgetId: Int, appWidget: AppWidgetProviderInfo?) {
        super.onProviderChanged(appWidgetId, appWidget)
        m.runOnUiThread { m.rebuildNative(appWidgetId) }
    }
}

/** Copies the resize rules from the provider (resize mode and minimum resize size). */
fun NativeWidget.applyInfo(info: AppWidgetProviderInfo) {
    resH = (info.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0
    resV = (info.resizeMode and AppWidgetProviderInfo.RESIZE_VERTICAL) != 0
    minW = if (resH) maxOf(info.minResizeWidth, 0).toFloat() else 0f
    minH = if (resV) maxOf(info.minResizeHeight, 0).toFloat() else 0f
}

/**
 * Full-screen layer that holds the real AppWidgetHostViews. It sits above the zone canvas.
 * Normal mode: touches reach the widgets (a long press on a widget enters edit mode).
 * Edit mode: touches are passed down to the zone canvas so widgets can be moved and resized.
 */
class NativeLayer(private val m: MainActivity) : FrameLayout(m) {
    class Item(val n: NativeWidget, var view: View)

    val items = ArrayList<Item>()
    var editing = false
    var selected: NativeWidget? = null
    var onLongPress: (() -> Unit)? = null
    private var pos = 0f
    private val d = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(m).scaledTouchSlop
    private var sx = 0f
    private var sy = 0f
    private var stolen = false
    private val rect = RectF()
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val longRun = Runnable { stolen = true; onLongPress?.invoke() }

    private fun lpFor(n: NativeWidget): LayoutParams =
        LayoutParams((n.r - n.l).toInt().coerceAtLeast(1), (n.b - n.t).toInt().coerceAtLeast(1)).apply {
            leftMargin = n.l.toInt(); topMargin = n.t.toInt()
        }

    fun add(n: NativeWidget, v: View) {
        v.cameraDistance = 12000f * d
        items.add(Item(n, v))
        addView(v, lpFor(n))
        applyTf(pos)
    }

    fun remove(n: NativeWidget) {
        val item = items.firstOrNull { it.n === n } ?: return
        removeView(item.view)
        items.remove(item)
        invalidate()
    }

    fun replace(n: NativeWidget, v: View) {
        val item = items.firstOrNull { it.n === n } ?: return
        removeView(item.view)
        v.cameraDistance = 12000f * d
        item.view = v
        addView(v, lpFor(n))
        applyTf(pos)
    }

    fun relayout(n: NativeWidget) {
        val item = items.firstOrNull { it.n === n } ?: return
        item.view.layoutParams = lpFor(n)
        applyTf(pos)
    }

    /** Applies the screen-change effect (cube, zoom, ...) to every widget, like the custom widgets. */
    fun applyTf(p: Float) {
        pos = p
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val fx = m.cfg.i("fx", 0)
        for (item in items) {
            val rel = item.n.page - p
            val v = item.view
            if (abs(rel) >= 1f) { v.visibility = View.INVISIBLE; continue }
            v.visibility = View.VISIBLE
            val t = Fx.tf(fx, rel, w, h)
            val lp = v.layoutParams as LayoutParams
            v.pivotX = t.px - lp.leftMargin; v.pivotY = t.py - lp.topMargin
            v.translationX = t.tx
            v.scaleX = t.sx; v.scaleY = t.sy
            v.rotationY = t.ry; v.rotation = t.rz
            v.alpha = t.a
        }
        invalidate()
    }

    private fun hitsWidget(x: Float, y: Float): Boolean = items.any {
        val v = it.view
        v.visibility == View.VISIBLE && x >= v.left && x <= v.right && y >= v.top && y <= v.bottom
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (editing) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; stolen = false
                removeCallbacks(longRun)
                // only start the long-press timer when the finger is really on a widget; otherwise
                // this layer never sees the UP event and the timer would fire on its own later
                if (hitsWidget(e.x, e.y)) postDelayed(longRun, m.cfg.i("hold_edit", 1000).toLong())
            }
            MotionEvent.ACTION_MOVE ->
                if (!stolen && (abs(e.x - sx) > slop || abs(e.y - sy) > slop)) removeCallbacks(longRun)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return stolen
    }

    // In edit mode returning false lets the zone canvas underneath receive the touch.
    override fun onTouchEvent(e: MotionEvent): Boolean = !editing && stolen

    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        if (!editing || abs(pos - Math.round(pos)) > 0.01f) return
        val pg = Math.round(pos)
        val acc = m.cfg.color("z_color", 1)
        for (item in items) {
            val n = item.n
            if (n.page != pg) continue
            val s = n === selected
            rect.set(n.l, n.t, n.r, n.b)
            framePaint.color = if (s) acc else 0xAAFFFFFF.toInt()
            framePaint.strokeWidth = (if (s) 3f else 1.5f) * d
            c.drawRoundRect(rect, 10 * d, 10 * d, framePaint)
            if (s && (n.resH || n.resV)) {
                for (px in listOf(n.l, n.r)) for (py in listOf(n.t, n.b)) c.drawCircle(px, py, 12 * d, dotPaint)
            }
        }
    }
}

/** "App Widgets" picker: lists every widget provider installed on the phone, grouped by app. */
class AppWidgetPicker(m: MainActivity) : PanelBase(m) {
    private val box = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL }
    private val list = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), dp(40)) }
    private val scroll = ScrollView(m)
    private var query = ""

    init { isClickable = true; visibility = View.GONE; scroll.addView(list); addView(box, LayoutParams(-1, -1)) }

    fun open() { query = ""; visibility = View.VISIBLE; refresh() }
    fun close() { visibility = View.GONE }

    override fun refresh() {
        themeUp()
        box.removeAllViews()
        val head = LinearLayout(m).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(32), dp(12), dp(8)) }
        head.addView(tv("App widgets", 20f, th.text, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(chip("Close", true) { close() })
        box.addView(head)
        val et = EditText(m).apply {
            hint = "Search apps or widgets"; isSingleLine = true
            setTextColor(th.text); setHintTextColor(th.sub)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            flat(th, 16, true)
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s.toString().trim().lowercase(); fill() }
        })
        box.addView(et, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), 0, dp(14), dp(6)) })
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fill()
    }

    private fun labelOf(info: AppWidgetProviderInfo): String =
        try { info.loadLabel(m.packageManager) ?: info.provider.shortClassName } catch (e: Exception) { info.provider.shortClassName }

    private fun fill() {
        list.removeAllViews()
        val pm = m.packageManager
        val dpi = resources.displayMetrics.densityDpi
        val all = try {
            m.awm.installedProviders.filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0 }
        } catch (e: Exception) { emptyList() }
        val rows = ArrayList<Triple<String, String, List<AppWidgetProviderInfo>>>()
        for ((pkg, infos) in all.groupBy { it.provider.packageName }) {
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            val matched = if (query.isEmpty() || app.lowercase().contains(query)) infos
                else infos.filter { labelOf(it).lowercase().contains(query) }
            if (matched.isNotEmpty()) rows.add(Triple(pkg, app, matched))
        }
        rows.sortBy { it.second.lowercase() }
        if (rows.isEmpty()) note(list, "No widgets found.")
        for ((pkg, app, infos) in rows) {
            val hd = LinearLayout(m).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(16), 0, dp(6)) }
            var ic: Drawable? = null
            try { ic = pm.getApplicationIcon(pkg) } catch (e: Exception) { }
            hd.addView(ImageView(m).apply { setImageDrawable(ic) }, LinearLayout.LayoutParams(dp(30), dp(30)))
            hd.addView(tv(app, 15f, accent, true).apply { setPadding(dp(10), 0, 0, 0) })
            list.addView(hd)
            for (info in infos) list.addView(widgetRow(info, dpi))
        }
    }

    private fun widgetRow(info: AppWidgetProviderInfo, dpi: Int): View {
        var pv: Drawable? = null
        try { pv = info.loadPreviewImage(m, 0) } catch (e: Exception) { }
        if (pv == null) { try { pv = info.loadIcon(m, dpi) } catch (e: Exception) { } }
        val cw = ((info.minWidth / d + 30) / 70).toInt().coerceAtLeast(1)
        val ch = ((info.minHeight / d + 30) / 70).toInt().coerceAtLeast(1)
        val resizable = (info.resizeMode and 3) != 0
        val row = LinearLayout(m).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            flat(th, 14)
            setOnClickListener { close(); m.addAppWidget(info) }
        }
        row.addView(ImageView(m).apply { setImageDrawable(pv); scaleType = ImageView.ScaleType.FIT_CENTER },
            LinearLayout.LayoutParams(dp(96), dp(64)))
        val col = LinearLayout(m).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(tv(labelOf(info), 14.5f, th.text, true))
        col.addView(tv("$cw × $ch cells  ·  " + (if (resizable) "Resizable" else "Fixed size"), 12f, th.sub))
        col.addView(tv("Min " + (info.minWidth / d).toInt() + " × " + (info.minHeight / d).toInt() + " dp", 12f, th.sub))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        return row.also { it.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) } }
    }
}
