package com.example.tapzones

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class Stats(ctx: Context) {
    private val p = ctx.getSharedPreferences("stats", 0)
    private fun dayKey(c: Calendar) = SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)

    fun hit(pkg: String, src: String) {
        val c = Calendar.getInstance()
        val e = p.edit()
        for (k in listOf("t|$pkg", "s|$src", "h|" + c.get(Calendar.HOUR_OF_DAY), "d|" + dayKey(c) + "|" + pkg)) {
            e.putInt(k, p.getInt(k, 0) + 1)
        }
        e.apply()
    }

    fun top(days: Int, n: Int): List<Pair<String, Int>> {
        val m = HashMap<String, Int>()
        if (days <= 0) {
            for ((k, v) in p.all) if (k.startsWith("t|") && v is Int) m[k.substring(2)] = v
        } else {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
            val cut = dayKey(cal)
            for ((k, v) in p.all) {
                if (!k.startsWith("d|") || v !is Int) continue
                val parts = k.split("|")
                if (parts.size == 3 && parts[1] >= cut) m[parts[2]] = (m[parts[2]] ?: 0) + v
            }
        }
        return m.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }
    }

    fun sources(): Map<String, Int> = listOf("zone", "shape", "list").associateWith { p.getInt("s|$it", 0) }

    fun hours(): IntArray {
        val a = IntArray(24)
        for (i in 0 until 24) a[i] = p.getInt("h|$i", 0)
        return a
    }

    fun reset() { p.edit().clear().apply() }
}
