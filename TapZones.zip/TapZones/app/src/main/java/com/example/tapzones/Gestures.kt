package com.example.tapzones

import android.app.Activity
import android.content.Context
import android.graphics.PointF
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

fun appLabel(a: Activity, pkg: String?): String = if (pkg == null) "none" else try {
    a.packageManager.getApplicationLabel(a.packageManager.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { "missing" }

object Rec {
    const val N = 64
    private fun pd(a: PointF, b: PointF) = hypot(b.x - a.x, b.y - a.y)

    fun norm(pts: List<PointF>): FloatArray? {
        if (pts.size < 2) return null
        var total = 0f
        for (i in 1 until pts.size) total += pd(pts[i - 1], pts[i])
        if (total < 20f) return null
        val step = total / (N - 1)
        val src = ArrayList<PointF>(pts)
        val out = ArrayList<PointF>()
        out.add(PointF(src[0].x, src[0].y))
        var acc = 0f
        var i = 1
        while (i < src.size) {
            val a = src[i - 1]; val b = src[i]
            val dd = pd(a, b)
            if (dd > 0f && acc + dd >= step) {
                val t = (step - acc) / dd
                val q = PointF(a.x + t * (b.x - a.x), a.y + t * (b.y - a.y))
                out.add(q); src.add(i, q); acc = 0f
            } else acc += dd
            i++
        }
        while (out.size < N) out.add(PointF(src.last().x, src.last().y))
        while (out.size > N) out.removeAt(out.size - 1)
        var minX = out[0].x; var maxX = minX; var minY = out[0].y; var maxY = minY
        for (p in out) {
            if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x
            if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y
        }
        val scale = max(1f, max(maxX - minX, maxY - minY))
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        val r = FloatArray(N * 2)
        for (k in 0 until N) { r[2 * k] = (out[k].x - cx) / scale; r[2 * k + 1] = (out[k].y - cy) / scale }
        return r
    }

    fun dist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (k in 0 until N) {
            val dx = a[2 * k] - b[2 * k]; val dy = a[2 * k + 1] - b[2 * k + 1]
            s += sqrt(dx * dx + dy * dy)
        }
        return s / N
    }
}

class GestureStore(ctx: Context) {
    class G(val pkg: String, val temps: List<FloatArray>)
    private val p = ctx.getSharedPreferences("gestures", 0)
    val list = mutableListOf<G>()

    init { load() }

    fun add(pkg: String, temps: List<FloatArray>) { list.add(G(pkg, temps)); save() }
    fun remove(i: Int) { if (i in list.indices) { list.removeAt(i); save() } }

    fun match(pts: List<PointF>, threshold: Float): String? {
        val n = Rec.norm(pts) ?: return null
        var best = Float.MAX_VALUE
        var bp: String? = null
        for (g in list) for (t in g.temps) {
            val d = Rec.dist(n, t)
            if (d < best) { best = d; bp = g.pkg }
        }
        return if (best <= threshold) bp else null
    }

    private fun save() {
        val arr = JSONArray()
        for (g in list) {
            val ts = JSONArray()
            for (t in g.temps) { val ja = JSONArray(); for (f in t) ja.put(f.toDouble()); ts.put(ja) }
            arr.put(JSONObject().put("pkg", g.pkg).put("t", ts))
        }
        p.edit().putString("g", arr.toString()).apply()
    }

    private fun load() {
        val s = p.getString("g", null) ?: return
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ts = o.getJSONArray("t")
                val temps = ArrayList<FloatArray>()
                for (j in 0 until ts.length()) {
                    val ja = ts.getJSONArray(j)
                    temps.add(FloatArray(ja.length()) { k -> ja.getDouble(k).toFloat() })
                }
                list.add(G(o.getString("pkg"), temps))
            }
        } catch (e: Exception) { list.clear() }
    }
}
