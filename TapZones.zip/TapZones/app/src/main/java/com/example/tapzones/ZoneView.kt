package com.example.tapzones

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt

class Zone(var l: Float, var t: Float, var r: Float, var b: Float,
           var dbl: String? = null, var sgl: String? = null, var page: Int = 0)

class ZoneView(private val a: Activity, private val cfg: Cfg, private val store: GestureStore) : View(a) {
    val zones = mutableListOf<Zone>()
    var edit = false
    var sel: Zone? = null
    var scrollPos = 0f
        private set
    var onChange: (() -> Unit)? = null
    var onScroll: ((Float) -> Unit)? = null
    var onSwipeUp: (() -> Unit)? = null
    var onSwipeDown: (() -> Unit)? = null
    var onSettings: (() -> Unit)? = null
    var onGesture: ((String) -> Unit)? = null
    var onLock: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val prefs = a.getSharedPreferences("zones", 0)
    private val pm = a.packageManager
    private val icons = HashMap<String, Drawable?>()
    private val slop = ViewConfiguration.get(a).scaledTouchSlop

    private val fill = Paint()
    private val line = Paint().apply { style = Paint.Style.STROKE }
    private val txt = Paint().apply { color = Color.WHITE; textSize = 12 * d; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
    private val dot = Paint().apply { color = Color.WHITE }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
    private val trailP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val cam = Camera()
    private val mx = Matrix()

    private var mode = 0
    private var cx = 0
    private var cy = 0
    private var lx = 0f
    private var ly = 0f
    private var sx = 0f
    private var sy = 0f
    private var t0 = 0L
    private var moved = false
    private var holdFired = false
    private var lastZone: Zone? = null
    private var lastBlank = false
    private var lastTime = 0L
    private var pending: Runnable? = null

    private val pts = ArrayList<PointF>()
    private val trail = Path()
    private var drawing = false
    private var pathLen = 0f

    private var pageDrag = false
    private var dragCancelled = false
    private var base = 0f
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null

    private val editRun = Runnable {
        holdFired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        clearTrail()
        setEditMode(true)
    }
    private val setRun = Runnable {
        holdFired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        clearTrail()
        onSettings?.invoke()
    }

    init { cam.setLocation(0f, 0f, -20f); load() }

    // ---------- pages ----------
    fun pageCount(): Int {
        if (zones.isEmpty()) return 1
        val m = zones.maxOf { it.page }
        return if (edit) m + 2 else m + 1
    }

    fun cur(): Int = scrollPos.roundToInt().coerceIn(0, pageCount() - 1)

    private fun setScroll(v: Float) { scrollPos = v; invalidate(); onScroll?.invoke(v) }

    fun goTo(page: Int, animate: Boolean = true) {
        val t = page.coerceIn(0, pageCount() - 1)
        anim?.cancel()
        sel = null
        if (!animate) { setScroll(t.toFloat()); onChange?.invoke(); return }
        val va = ValueAnimator.ofFloat(scrollPos, t.toFloat())
        va.duration = cfg.i("pg_ms", 280).toLong()
        va.interpolator = DecelerateInterpolator(1.5f)
        va.addUpdateListener { setScroll(it.animatedValue as Float) }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onChange?.invoke() }
        })
        anim = va
        va.start()
    }

    private fun compact() {
        val used = zones.map { it.page }.distinct().sorted()
        for (z in zones) z.page = used.indexOf(z.page)
    }

    private fun elastic(raw: Float): Float {
        val mx2 = (pageCount() - 1).toFloat()
        return when {
            raw < 0f -> raw * 0.3f
            raw > mx2 -> mx2 + (raw - mx2) * 0.3f
            else -> raw
        }
    }

    // ---------- basics ----------
    private fun cancelHolds() { removeCallbacks(editRun); removeCallbacks(setRun) }
    private fun clearTrail() { drawing = false; trail.reset(); pts.clear(); invalidate() }
    private fun endVt() { vt?.recycle(); vt = null }

    fun setEditMode(on: Boolean) {
        edit = on; sel = null
        if (!on) {
            compact()
            setScroll(scrollPos.roundToInt().coerceIn(0, pageCount() - 1).toFloat())
            save()
        }
        invalidate(); onChange?.invoke()
    }

    fun addZone(pkg: String? = null) {
        val s = 120 * d; val x = width / 2f; val y = height / 2f
        val z = Zone(x - s / 2, y - s / 2, x + s / 2, y + s / 2, pkg, null, cur())
        zones.add(z); sel = z; save(); invalidate(); onChange?.invoke()
    }

    fun deleteSelected() {
        sel?.let { zones.remove(it) }
        sel = null; save(); invalidate(); onChange?.invoke()
    }

    fun resetAll() {
        zones.clear(); sel = null; save(); setScroll(0f); onChange?.invoke()
    }

    private fun hit(x: Float, y: Float): Zone? {
        val pg = cur()
        return zones.lastOrNull { it.page == pg && x in it.l..it.r && y in it.t..it.b }
    }

    private fun open(pkg: String) {
        if (cfg.b("z_vib", true)) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val i = pm.getLaunchIntentForPackage(pkg)
        if (i != null) a.startActivity(i) else Toast.makeText(a, "App not found", Toast.LENGTH_SHORT).show()
    }

    private fun icon(pkg: String): Drawable? = icons.getOrPut(pkg) {
        try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
    }

    private fun tap(x: Float, y: Float) {
        val z = hit(x, y)
        val now = SystemClock.uptimeMillis()
        val dt = cfg.i("dt_ms", 300).toLong()
        if (z == null) {
            pending?.let { removeCallbacks(it) }; pending = null; lastZone = null
            if (lastBlank && now - lastTime < dt) {
                lastBlank = false
                if (cfg.b("lock_on", true)) onLock?.invoke()
                return
            }
            lastBlank = true; lastTime = now
            return
        }
        lastBlank = false
        if (z === lastZone && now - lastTime < dt) {
            pending?.let { removeCallbacks(it) }; pending = null; lastZone = null
            z.dbl?.let { open(it) }
            return
        }
        pending?.let { removeCallbacks(it) }; pending = null
        lastZone = z; lastTime = now
        val s = z.sgl
        if (s != null) {
            val r = Runnable { pending = null; open(s) }
            pending = r; postDelayed(r, dt)
        }
    }

    // ---------- touch ----------
    private fun normalTouch(e: MotionEvent): Boolean {
        if (holdFired && e.actionMasked == MotionEvent.ACTION_MOVE) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                base = scrollPos
                pageDrag = false; dragCancelled = false
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                drawing = hit(e.x, e.y) == null
                pts.clear(); pts.add(PointF(e.x, e.y))
                pathLen = 0f; trail.reset(); trail.moveTo(e.x, e.y)
                val he = cfg.i("hold_edit", 1000)
                postDelayed(editRun, he.toLong())
                postDelayed(setRun, maxOf(cfg.i("hold_set", 5000), he + 500).toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (pts.isNotEmpty() && pts.size < 3000) {
                    val last = pts[pts.size - 1]
                    pathLen += hypot(e.x - last.x, e.y - last.y)
                    pts.add(PointF(e.x, e.y)); trail.lineTo(e.x, e.y)
                }
                if (!moved && (abs(e.x - sx) > slop || abs(e.y - sy) > slop)) { moved = true; cancelHolds() }
                if (moved) {
                    val dx = e.x - sx; val dy = e.y - sy
                    val disp = hypot(dx, dy)
                    if (!pageDrag && !dragCancelled && pageCount() > 1 && cfg.b("pg_on", true) &&
                        abs(dx) > 2 * slop && abs(dy) < abs(dx) * 0.45f && pathLen < disp * 1.15f) pageDrag = true
                    if (pageDrag) {
                        if (abs(dy) > abs(dx) * 0.8f || pathLen > disp * 1.4f) {
                            pageDrag = false; dragCancelled = true; goTo(base.roundToInt())
                        } else setScroll(elastic(base - dx / width))
                    } else if (drawing && cfg.b("g_show", true)) invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                cancelHolds()
                if (holdFired) { clearTrail(); endVt(); return true }
                if (pageDrag) {
                    vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val c0 = base.roundToInt()
                    val target = when {
                        vx < -700 * d -> c0 + 1
                        vx > 700 * d -> c0 - 1
                        else -> scrollPos.roundToInt()
                    }
                    pageDrag = false; endVt(); clearTrail(); goTo(target)
                    return true
                }
                if (moved) {
                    val dx = e.x - sx; val dy = e.y - sy
                    val straight = pathLen < hypot(dx, dy) * 1.3f
                    val fast = e.eventTime - t0 < 900
                    if (straight && fast && abs(dy) > abs(dx) * 1.5f && abs(dy) > 80 * d) {
                        if (dy < 0) onSwipeUp?.invoke() else if (cfg.b("sd_on", true)) onSwipeDown?.invoke()
                    } else if (drawing && cfg.b("g_on", true) && pts.size > 8) {
                        val th = when (cfg.i("g_acc", 1)) { 0 -> 0.09f; 2 -> 0.20f; else -> 0.14f }
                        store.match(pts, th)?.let { onGesture?.invoke(it) }
                    }
                } else tap(e.x, e.y)
                clearTrail(); endVt()
                if (abs(scrollPos - scrollPos.roundToInt()) > 0.001f) goTo(scrollPos.roundToInt())
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelHolds(); clearTrail(); endVt()
                if (pageDrag) { pageDrag = false; goTo(scrollPos.roundToInt()) }
            }
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            sx = x; sy = y; t0 = e.eventTime; holdFired = false; moved = false
        }
        if (!edit) return normalTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = 0; lx = x; ly = y
                val s = sel
                if (s != null) {
                    val r = 36 * d
                    for (ix in 0..1) for (iy in 0..1) {
                        val px = if (ix == 0) s.l else s.r
                        val py = if (iy == 0) s.t else s.b
                        if (abs(x - px) < r && abs(y - py) < r) { mode = 2; cx = ix; cy = iy; return true }
                    }
                }
                val h = hit(x, y)
                sel = h
                if (h != null) { zones.remove(h); zones.add(h); mode = 1 }
                invalidate(); onChange?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(x - sx) > slop || abs(y - sy) > slop) removeCallbacks(setRun)
                val s = sel ?: return true
                val dx = x - lx; val dy = y - ly; lx = x; ly = y
                val min = 48 * d
                if (mode == 1) { s.l += dx; s.r += dx; s.t += dy; s.b += dy }
                else if (mode == 2) {
                    if (cx == 0) s.l = minOf(s.l + dx, s.r - min) else s.r = maxOf(s.r + dx, s.l + min)
                    if (cy == 0) s.t = minOf(s.t + dy, s.b - min) else s.b = maxOf(s.b + dy, s.t + min)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { removeCallbacks(setRun); save(); mode = 0 }
        }
        return true
    }

    // ---------- drawing ----------
    private fun applyTf(c: Canvas, t: Tf) {
        c.translate(t.tx, 0f)
        if (t.sx != 1f || t.sy != 1f) c.scale(t.sx, t.sy, t.px, t.py)
        if (t.rz != 0f) c.rotate(t.rz, t.px, t.py)
        if (t.ry != 0f) {
            cam.save(); cam.rotateY(t.ry); cam.getMatrix(mx); cam.restore()
            mx.preTranslate(-t.px, -t.py); mx.postTranslate(t.px, t.py)
            c.concat(mx)
        }
    }

    override fun onDraw(c: Canvas) {
        if (!edit && drawing && moved && !pageDrag && cfg.b("g_show", true)) {
            trailP.color = cfg.color("g_color", 1)
            c.drawPath(trail, trailP)
        }
        if (edit || cfg.b("z_vis", false)) {
            val w = width.toFloat(); val h = height.toFloat()
            val n = pageCount()
            val first = floor(scrollPos).toInt().coerceAtLeast(0)
            val last = ceil(scrollPos).toInt().coerceAtMost(n - 1)
            val fx = cfg.i("fx", 0)
            for (pg in first..last) {
                val tf = Fx.tf(fx, pg - scrollPos, w, h)
                if (tf.a <= 0.01f) continue
                val saved = c.save()
                if (tf.a < 0.99f) c.saveLayerAlpha(0f, 0f, w, h, (tf.a * 255).toInt())
                applyTf(c, tf)
                drawPage(c, pg)
                c.restoreToCount(saved)
            }
        }
        drawDots(c)
    }

    private fun drawDots(c: Canvas) {
        val n = pageCount()
        if (n < 2 || !cfg.b("dots_on", true)) return
        val cyy = height - 84 * d
        val gap = 16 * d
        val x0 = width / 2f - (n - 1) * gap / 2f
        for (i in 0 until n) {
            val dist = minOf(abs(i - scrollPos), 1f)
            dotP.alpha = (255 * (1f - 0.65f * dist)).toInt()
            c.drawCircle(x0 + i * gap, cyy, (3.5f + 1.5f * (1f - dist)) * d, dotP)
        }
    }

    private fun drawPage(c: Canvas, pg: Int) {
        val acc = cfg.color("z_color", 1)
        fill.color = (acc and 0xFFFFFF) or ((cfg.i("z_alpha", 25) * 255 / 100) shl 24)
        line.color = (acc and 0xFFFFFF) or 0xCC000000.toInt()
        val ic = (36 * d).toInt()
        for (z in zones) {
            if (z.page != pg) continue
            val r = RectF(z.l, z.t, z.r, z.b)
            c.drawRoundRect(r, 12 * d, 12 * d, fill)
            line.strokeWidth = (if (edit && z === sel) 4 else 2) * d
            c.drawRoundRect(r, 12 * d, 12 * d, line)
            c.save(); c.clipRect(r)
            var x = (z.l + 6 * d).toInt()
            val y = (z.t + 6 * d).toInt()
            if (edit && z.dbl == null && z.sgl == null) c.drawText("empty", z.l + 6 * d, z.t + 22 * d, txt)
            listOf("2x" to z.dbl, "1x" to z.sgl).forEach { (tag, pkg) ->
                if (pkg != null) {
                    icon(pkg)?.let { dr -> dr.setBounds(x, y, x + ic, y + ic); dr.draw(c) }
                    if (edit) c.drawText(tag, x.toFloat(), y + ic + 14 * d, txt)
                    x += ic + (8 * d).toInt()
                }
            }
            c.restore()
            if (edit && z === sel) for (px in listOf(z.l, z.r)) for (py in listOf(z.t, z.b)) c.drawCircle(px, py, 12 * d, dot)
        }
    }

    // ---------- storage ----------
    fun save() {
        val arr = JSONArray()
        zones.forEach {
            arr.put(JSONObject().put("l", it.l.toDouble()).put("t", it.t.toDouble())
                .put("r", it.r.toDouble()).put("b", it.b.toDouble()).put("pg", it.page)
                .put("dbl", it.dbl ?: JSONObject.NULL).put("sgl", it.sgl ?: JSONObject.NULL))
        }
        prefs.edit().putString("z", arr.toString()).apply()
    }

    private fun load() {
        val s = prefs.getString("z", null) ?: return
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                zones.add(Zone(o.getDouble("l").toFloat(), o.getDouble("t").toFloat(),
                    o.getDouble("r").toFloat(), o.getDouble("b").toFloat(),
                    if (o.isNull("dbl")) null else o.getString("dbl"),
                    if (o.isNull("sgl")) null else o.getString("sgl"),
                    o.optInt("pg", 0)))
            }
            compact()
        } catch (e: Exception) { zones.clear() }
    }
}
