package com.example.tapzones

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt

class ZoneView(private val a: Activity, private val cfg: Cfg, private val store: GestureStore,
               val look: Look, private val stats: Stats) : View(a) {
    val zones = mutableListOf<Zone>()
    var edit = false
    var selBox: Box? = null
    val sel: Zone? get() = selBox as? Zone
    val selW: Widget? get() = selBox as? Widget
    val selN: NativeWidget? get() = selBox as? NativeWidget
    var onScroll: (() -> Unit)? = null
    var onNativeGeom: ((NativeWidget, Boolean) -> Unit)? = null
    var onNativeRemoved: ((NativeWidget) -> Unit)? = null
    var batt = -1
    var scrollPos = 0f
        private set
    var onChange: (() -> Unit)? = null
    var onSwipeUp: (() -> Unit)? = null
    var onSwipeDown: (() -> Unit)? = null
    var onEditRequest: (() -> Unit)? = null
    var onSettings: (() -> Unit)? = null
    var onAdvanced: (() -> Unit)? = null
    var onAdvCue: (() -> Unit)? = null
    var onGesture: ((String) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val prefs = a.getSharedPreferences("zones", 0)
    private val pm = a.packageManager
    private val icons = HashMap<String, Drawable?>()
    private val slop = ViewConfiguration.get(a).scaledTouchSlop

    private val fill = Paint()
    private val line = Paint().apply { style = Paint.Style.STROKE }
    private val txt = Paint().apply { color = Color.WHITE; textSize = 12 * d; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
    private val dot = Paint().apply { color = Color.WHITE }
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
    private val bgP = Paint()
    private val trailP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val cam = Camera()
    private val mx = Matrix()
    private val wr = RectF()
    private var hintText: String? = null
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 15 * d }
    private val hintBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }

    private var mode = 0
    private var cx = 0
    private var cy = 0
    private var lx = 0f
    private var ly = 0f
    private var sx = 0f
    private var sy = 0f
    private var t0 = 0L
    private var moved = false
    private var holdFired = false
    private var holdLevel = 0
    private var lngZone: Zone? = null
    private var lastZone: Zone? = null
    private var lastTime = 0L
    private var pending: Runnable? = null

    private val pts = ArrayList<PointF>()
    private val trail = Path()
    private var drawing = false
    private var pathLen = 0f
    private var lpx = 0f
    private var lpy = 0f

    private var pageDrag = false
    private var dragCancelled = false
    private var base = 0f
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null

    private fun lockEdit() = cfg.hasPin() && cfg.b("lock_edit", false)

    private val editRun = Runnable {
        holdFired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        clearTrail()
        if (lockEdit()) holdLevel = 1 else setEditMode(true)
    }
    private val setRun = Runnable {
        holdFired = true; holdLevel = 2
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        clearTrail()
        hintText = "Release now for Settings"; invalidate()
    }
    private val advRun = Runnable {
        holdFired = true; holdLevel = 3
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        clearTrail()
        hintText = null; invalidate()
        onAdvCue?.invoke()
    }
    private val lngRun = Runnable {
        val p = lngZone?.lng
        if (p != null) {
            cancelHolds()
            holdFired = true; holdLevel = 0
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            clearTrail()
            open(p)
        }
    }

    init { cam.setLocation(0f, 0f, -20f); load() }

    // ---------- pages ----------
    private fun maxPage(): Int {
        var m = -1
        for (z in zones) if (z.page > m) m = z.page
        for (w in look.widgets) if (w.page > m) m = w.page
        for (n in look.natives) if (n.page > m) m = n.page
        return m
    }

    fun contentPages(): Int = maxOf(1, maxPage() + 1)

    fun pageCount(): Int {
        val m = maxPage()
        if (m < 0) return 1
        return if (edit) m + 2 else m + 1
    }

    fun cur(): Int = scrollPos.roundToInt().coerceIn(0, pageCount() - 1)

    private fun setScroll(v: Float) { scrollPos = v; invalidate(); onScroll?.invoke() }

    fun goTo(page: Int, animate: Boolean = true) {
        val t = page.coerceIn(0, pageCount() - 1)
        anim?.cancel()
        selBox = null
        if (!animate) { setScroll(t.toFloat()); onChange?.invoke(); return }
        val va = ValueAnimator.ofFloat(scrollPos, t.toFloat())
        va.duration = cfg.i("pg_ms", 280).toLong()
        va.interpolator = DecelerateInterpolator(1.5f)
        va.addUpdateListener { setScroll(it.animatedValue as Float) }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onChange?.invoke() }
        })
        anim = va
        va.start()
    }

    private fun compact() {
        val used = (zones.map { it.page } + look.widgets.map { it.page } + look.natives.map { it.page }).distinct().sorted()
        if (used.isEmpty()) return
        val old = HashMap(look.pages)
        for (z in zones) z.page = used.indexOf(z.page)
        for (w in look.widgets) w.page = used.indexOf(w.page)
        for (n in look.natives) n.page = used.indexOf(n.page)
        look.pages.clear()
        used.forEachIndexed { ni, oi -> old[oi]?.let { look.pages[ni] = it } }
    }

    private fun elastic(raw: Float): Float {
        val top = (pageCount() - 1).toFloat()
        return when {
            raw < 0f -> raw * 0.3f
            raw > top -> top + (raw - top) * 0.3f
            else -> raw
        }
    }

    // ---------- basics ----------
    private fun cancelHolds() {
        removeCallbacks(editRun); removeCallbacks(setRun); removeCallbacks(advRun); removeCallbacks(lngRun)
    }
    private fun clearTrail() { drawing = false; trail.reset(); pts.clear(); invalidate() }
    private fun endVt() { vt?.recycle(); vt = null }

    fun setEditMode(on: Boolean) {
        edit = on; selBox = null
        if (!on) {
            compact()
            setScroll(scrollPos.roundToInt().coerceIn(0, pageCount() - 1).toFloat())
            save()
        }
        invalidate(); onChange?.invoke()
    }

    fun addZone(pkg: String? = null) {
        val s = 120 * d; val x = width / 2f; val y = height / 2f
        val z = Zone(x - s / 2, y - s / 2, x + s / 2, y + s / 2, pkg, null, cur())
        zones.add(z); selBox = z; save(); invalidate(); onChange?.invoke()
    }

    fun addWidget(type: Int, style: Int): Widget {
        val w = Widget(0f, 0f, 0f, 0f, cur(), type, style)
        ClockStyles.defaults(w)
        val (wd, hd) = ClockStyles.size(w)
        val x = width / 2f; val y = height * 0.3f
        w.l = x - wd * d / 2; w.r = x + wd * d / 2; w.t = y - hd * d / 2; w.b = y + hd * d / 2
        look.widgets.add(w); selBox = w; save(); invalidate(); onChange?.invoke()
        return w
    }

    fun deleteWidget(w: Widget) {
        look.widgets.remove(w)
        if (selBox === w) selBox = null
        save(); invalidate(); onChange?.invoke()
    }

    fun deleteSelected() {
        val s = selBox
        if (s is Zone) zones.remove(s)
        else if (s is Widget) look.widgets.remove(s)
        else if (s is NativeWidget) { look.natives.remove(s); onNativeRemoved?.invoke(s) }
        selBox = null; save(); invalidate(); onChange?.invoke()
    }

    fun resetAll() {
        zones.clear(); selBox = null; save(); setScroll(0f); onChange?.invoke()
    }

    fun resetEverything() {
        for (n in look.natives.toList()) onNativeRemoved?.invoke(n)
        zones.clear(); look.widgets.clear(); look.natives.clear(); look.pages.clear()
        selBox = null; save(); setScroll(0f); onChange?.invoke()
    }

    fun persistLook() { look.save(); invalidate() }

    private fun hit(x: Float, y: Float): Zone? {
        val pg = cur()
        return zones.lastOrNull { it.page == pg && x in it.l..it.r && y in it.t..it.b }
    }

    private fun hitBox(x: Float, y: Float): Box? {
        val pg = cur()
        val nw: Box? = look.natives.lastOrNull { it.page == pg && x in it.l..it.r && y in it.t..it.b }
        if (nw != null) return nw
        val z: Box? = zones.lastOrNull { it.page == pg && x in it.l..it.r && y in it.t..it.b }
        if (z != null) return z
        return look.widgets.lastOrNull { it.page == pg && x in it.l..it.r && y in it.t..it.b }
    }

    private fun open(pkg: String) {
        if (cfg.b("z_vib", true)) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        val i = pm.getLaunchIntentForPackage(pkg)
        if (i != null) { stats.hit(pkg, "zone"); a.startActivity(i) }
        else Toast.makeText(a, "App not found", Toast.LENGTH_SHORT).show()
    }

    private fun icon(pkg: String): Drawable? = icons.getOrPut(pkg) {
        try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
    }

    private fun tap(x: Float, y: Float) {
        val z = hit(x, y)
        val now = SystemClock.uptimeMillis()
        val dt = cfg.i("dt_ms", 300).toLong()
        if (z == null) { pending?.let { removeCallbacks(it) }; pending = null; lastZone = null; return }
        if (z === lastZone && now - lastTime < dt) {
            pending?.let { removeCallbacks(it) }; pending = null; lastZone = null
            z.dbl?.let { open(it) }
            return
        }
        pending?.let { removeCallbacks(it) }; pending = null
        lastZone = z; lastTime = now
        val s = z.sgl
        if (s != null) {
            val r = Runnable { pending = null; open(s) }
            pending = r; postDelayed(r, dt)
        }
    }

    private fun finishHold() {
        val h = holdLevel
        holdLevel = 0
        hintText = null
        when (h) {
            1 -> onEditRequest?.invoke()
            2 -> { setEditMode(false); onSettings?.invoke() }
            3 -> { setEditMode(false); onAdvanced?.invoke() }
        }
    }

    // ---------- touch ----------
    private fun normalTouch(e: MotionEvent): Boolean {
        if (holdFired && e.actionMasked == MotionEvent.ACTION_MOVE) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                base = scrollPos
                pageDrag = false; dragCancelled = false
                vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                val z = hit(e.x, e.y)
                drawing = z == null && cfg.b("g_on", true)
                pts.clear(); if (drawing) pts.add(PointF(e.x, e.y))
                pathLen = 0f; lpx = e.x; lpy = e.y; trail.reset(); trail.moveTo(e.x, e.y)
                lngZone = z
                if (z?.lng != null) postDelayed(lngRun, 500)
                val he = cfg.i("hold_edit", 1000)
                val hs = maxOf(cfg.i("hold_set", 5000), he + 500)
                postDelayed(editRun, he.toLong())
                postDelayed(setRun, hs.toLong())
                postDelayed(advRun, maxOf(7000, hs + 1000).toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                pathLen += hypot(e.x - lpx, e.y - lpy); lpx = e.x; lpy = e.y
                if (drawing && pts.size < 3000) { pts.add(PointF(e.x, e.y)); trail.lineTo(e.x, e.y) }
                if (!moved && (abs(e.x - sx) > slop || abs(e.y - sy) > slop)) { moved = true; cancelHolds() }
                if (moved) {
                    val dx = e.x - sx; val dy = e.y - sy
                    val disp = hypot(dx, dy)
                    if (!pageDrag && !dragCancelled && pageCount() > 1 && cfg.b("pg_on", true) &&
                        abs(dx) > 2 * slop && abs(dy) < abs(dx) * 0.45f && pathLen < disp * 1.15f) pageDrag = true
                    if (pageDrag) {
                        if (abs(dy) > abs(dx) * 0.8f || pathLen > disp * 1.4f) {
                            pageDrag = false; dragCancelled = true; goTo(base.roundToInt())
                        } else setScroll(elastic(base - dx / width))
                    } else if (drawing && cfg.b("g_show", true)) invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                cancelHolds()
                if (holdFired) { finishHold(); clearTrail(); endVt(); return true }
                if (pageDrag) {
                    vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val c0 = base.roundToInt()
                    val target = when {
                        vx < -700 * d -> c0 + 1
                        vx > 700 * d -> c0 - 1
                        else -> scrollPos.roundToInt()
                    }
                    pageDrag = false; endVt(); clearTrail(); goTo(target)
                    return true
                }
                if (moved) {
                    val dx = e.x - sx; val dy = e.y - sy
                    val straight = pathLen < hypot(dx, dy) * 1.3f
                    val fast = e.eventTime - t0 < 900
                    if (straight && fast && abs(dy) > abs(dx) * 1.5f && abs(dy) > 80 * d) {
                        if (dy < 0) onSwipeUp?.invoke() else if (cfg.b("sd_on", true)) onSwipeDown?.invoke()
                    } else if (drawing && cfg.b("g_on", true) && pts.size > 8) {
                        val th = when (cfg.i("g_acc", 1)) { 0 -> 0.09f; 2 -> 0.20f; else -> 0.14f }
                        store.match(pts, th)?.let { onGesture?.invoke(it) }
                    }
                } else tap(e.x, e.y)
                clearTrail(); endVt()
                if (abs(scrollPos - scrollPos.roundToInt()) > 0.001f) goTo(scrollPos.roundToInt())
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelHolds(); clearTrail(); endVt(); holdLevel = 0; hintText = null
                if (pageDrag) { pageDrag = false; goTo(scrollPos.roundToInt()) }
            }
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            sx = x; sy = y; t0 = e.eventTime; holdFired = false; moved = false; holdLevel = 0; hintText = null
        }
        if (!edit) return normalTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = 0; lx = x; ly = y
                val s = selBox
                if (s != null && (s.resH || s.resV)) {
                    val r = 36 * d
                    for (ix in 0..1) for (iy in 0..1) {
                        val px = if (ix == 0) s.l else s.r
                        val py = if (iy == 0) s.t else s.b
                        if (abs(x - px) < r && abs(y - py) < r) { mode = 2; cx = ix; cy = iy; return true }
                    }
                }
                val h = hitBox(x, y)
                selBox = h
                if (h is Zone) { zones.remove(h); zones.add(h); mode = 1 }
                else if (h is Widget) { look.widgets.remove(h); look.widgets.add(h); mode = 1 }
                else if (h != null) mode = 1
                invalidate(); onChange?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(x - sx) > slop || abs(y - sy) > slop) { removeCallbacks(setRun); removeCallbacks(advRun); hintText = null; holdLevel = 0 }
                val s = selBox ?: return true
                val dx = x - lx; val dy = y - ly; lx = x; ly = y
                val min = (if (s is Widget) 60 else 48) * d
                if (mode == 1) { s.l += dx; s.r += dx; s.t += dy; s.b += dy }
                else if (mode == 2) {
                    val mw = maxOf(min, s.minW); val mh = maxOf(min, s.minH)
                    if (s.resH) { if (cx == 0) s.l = minOf(s.l + dx, s.r - mw) else s.r = maxOf(s.r + dx, s.l + mw) }
                    if (s.resV) { if (cy == 0) s.t = minOf(s.t + dy, s.b - mh) else s.b = maxOf(s.b + dy, s.t + mh) }
                }
                if (s is NativeWidget) onNativeGeom?.invoke(s, false)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(setRun); removeCallbacks(advRun)
                if (e.actionMasked == MotionEvent.ACTION_UP && holdLevel >= 2) { finishHold(); return true }
                val sn = selBox
                if (sn is NativeWidget && mode != 0) onNativeGeom?.invoke(sn, true)
                save(); mode = 0
            }
        }
        return true
    }

    // ---------- drawing ----------
    private fun applyTf(c: Canvas, t: Tf) {
        c.translate(t.tx, 0f)
        if (t.sx != 1f || t.sy != 1f) c.scale(t.sx, t.sy, t.px, t.py)
        if (t.rz != 0f) c.rotate(t.rz, t.px, t.py)
        if (t.ry != 0f) {
            cam.save(); cam.rotateY(t.ry); cam.getMatrix(mx); cam.restore()
            mx.preTranslate(-t.px, -t.py); mx.postTranslate(t.px, t.py)
            c.concat(mx)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val n = pageCount()
        val first = floor(scrollPos).toInt().coerceAtLeast(0)
        val last = ceil(scrollPos).toInt().coerceAtMost(n - 1)
        val fx = cfg.i("fx", 0)
        val cal = Calendar.getInstance()
        for (pg in first..last) {
            val tf = Fx.tf(fx, pg - scrollPos, w, h)
            if (tf.a <= 0.01f) continue
            val saved = c.save()
            if (tf.a < 0.99f) c.saveLayerAlpha(0f, 0f, w, h, (tf.a * 255).toInt())
            applyTf(c, tf)
            drawBg(c, pg, w, h)
            for (wd in look.widgets) {
                if (wd.page != pg) continue
                wr.set(wd.l, wd.t, wd.r, wd.b)
                ClockDraw.draw(c, wd, wr, cal, batt, d)
            }
            if (edit || cfg.b("z_vis", false)) drawZones(c, pg)
            if (edit) drawWidgetFrames(c, pg)
            c.restoreToCount(saved)
        }
        if (!edit && drawing && moved && !pageDrag && cfg.b("g_show", true)) {
            trailP.color = cfg.color("g_color", 1)
            c.drawPath(trail, trailP)
        }
        drawDots(c)
        hintText?.let {
            val tw = hintP.measureText(it)
            val cx2 = w / 2; val cy2 = h * 0.5f
            c.drawRoundRect(cx2 - tw / 2 - 20 * d, cy2 - 26 * d, cx2 + tw / 2 + 20 * d, cy2 + 26 * d, 26 * d, 26 * d, hintBg)
            c.drawText(it, cx2, cy2 + 5 * d, hintP)
        }
    }

    private fun drawBg(c: Canvas, pg: Int, w: Float, h: Float) {
        val pl = look.pages[pg] ?: return
        val c1 = PALETTE[pl.c1.coerceIn(0, PALETTE.size - 1)]
        val c2 = PALETTE[pl.c2.coerceIn(0, PALETTE.size - 1)]
        if (pl.mode == 1) {
            bgP.shader = null; bgP.color = c1; c.drawRect(0f, 0f, w, h, bgP)
        } else if (pl.mode == 2) {
            bgP.shader = LinearGradient(0f, 0f, 0f, h, c1, c2, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, bgP); bgP.shader = null
        }
        if (pl.dim > 0) { bgP.shader = null; bgP.color = Color.argb(pl.dim * 255 / 100, 0, 0, 0); c.drawRect(0f, 0f, w, h, bgP) }
    }

    private fun drawWidgetFrames(c: Canvas, pg: Int) {
        val acc = cfg.color("z_color", 1)
        for (wd in look.widgets) {
            if (wd.page != pg) continue
            val s = wd === selBox
            wr.set(wd.l, wd.t, wd.r, wd.b)
            line.color = if (s) acc else 0xAAFFFFFF.toInt()
            line.strokeWidth = (if (s) 3f else 1.5f) * d
            c.drawRoundRect(wr, 10 * d, 10 * d, line)
            if (s) for (px in listOf(wd.l, wd.r)) for (py in listOf(wd.t, wd.b)) c.drawCircle(px, py, 12 * d, dot)
        }
    }

    private fun drawDots(c: Canvas) {
        val n = pageCount()
        if (n < 2 || !cfg.b("dots_on", true)) return
        val cyy = height - 84 * d
        val gap = 16 * d
        val x0 = width / 2f - (n - 1) * gap / 2f
        for (i in 0 until n) {
            val dist = minOf(abs(i - scrollPos), 1f)
            dotP.alpha = (255 * (1f - 0.65f * dist)).toInt()
            c.drawCircle(x0 + i * gap, cyy, (3.5f + 1.5f * (1f - dist)) * d, dotP)
        }
    }

    private fun drawZones(c: Canvas, pg: Int) {
        val acc = cfg.color("z_color", 1)
        fill.color = (acc and 0xFFFFFF) or ((cfg.i("z_alpha", 25) * 255 / 100) shl 24)
        line.color = (acc and 0xFFFFFF) or 0xCC000000.toInt()
        val ic = (36 * d).toInt()
        for (z in zones) {
            if (z.page != pg) continue
            val r = RectF(z.l, z.t, z.r, z.b)
            c.drawRoundRect(r, 12 * d, 12 * d, fill)
            line.strokeWidth = (if (edit && z === selBox) 4 else 2) * d
            c.drawRoundRect(r, 12 * d, 12 * d, line)
            c.save(); c.clipRect(r)
            var x = (z.l + 6 * d).toInt()
            val y = (z.t + 6 * d).toInt()
            if (edit && z.dbl == null && z.sgl == null && z.lng == null) c.drawText("empty", z.l + 6 * d, z.t + 22 * d, txt)
            listOf("2x" to z.dbl, "1x" to z.sgl, "L" to z.lng).forEach { (tag, pkg) ->
                if (pkg != null) {
                    icon(pkg)?.let { dr -> dr.setBounds(x, y, x + ic, y + ic); dr.draw(c) }
                    if (edit) c.drawText(tag, x.toFloat(), y + ic + 14 * d, txt)
                    x += ic + (8 * d).toInt()
                }
            }
            c.restore()
            if (edit && z === selBox) for (px in listOf(z.l, z.r)) for (py in listOf(z.t, z.b)) c.drawCircle(px, py, 12 * d, dot)
        }
    }

    // ---------- storage ----------
    fun save() {
        val arr = JSONArray()
        zones.forEach {
            arr.put(JSONObject().put("l", it.l.toDouble()).put("t", it.t.toDouble())
                .put("r", it.r.toDouble()).put("b", it.b.toDouble()).put("pg", it.page)
                .put("dbl", it.dbl ?: JSONObject.NULL).put("sgl", it.sgl ?: JSONObject.NULL)
                .put("lng", it.lng ?: JSONObject.NULL))
        }
        prefs.edit().putString("z", arr.toString()).apply()
        look.save()
    }

    private fun load() {
        val s = prefs.getString("z", null)
        if (s != null) {
            try {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    zones.add(Zone(o.getDouble("l").toFloat(), o.getDouble("t").toFloat(),
                        o.getDouble("r").toFloat(), o.getDouble("b").toFloat(),
                        if (o.isNull("dbl")) null else o.getString("dbl"),
                        if (o.isNull("sgl")) null else o.getString("sgl"),
                        o.optInt("pg", 0),
                        if (o.isNull("lng")) null else o.optString("lng", "").ifEmpty { null }))
                }
            } catch (e: Exception) { zones.clear() }
        }
        compact()
    }
}
